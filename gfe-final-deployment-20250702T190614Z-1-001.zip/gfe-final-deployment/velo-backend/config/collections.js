// backend/config/collections.js - Fixed version with comprehensive field mappings
// Good Faith Exteriors - Wix Collections Configuration

/**
 * Comprehensive collection field mappings for GFE system
 * Maps all Wix collection fields to proper types, validators, and handlers
 */

// Fixed regex pattern - was: /[x00-\x1F\x7F]/ (invalid range)
// Now: /[\x00-\x1F\x7F]/ (valid range for control characters)
const CONTROL_CHARS_REGEX = /[\x00-\x1F\x7F]/g;

export const COLLECTIONS_CONFIG = {
    // CRM Leads Collection
    CrmLeads: {
        collectionId: 'CrmLeads',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            fullName: { type: 'text', wixId: 'fullName', required: true },
            email: { type: 'text', wixId: 'email', required: true },
            phone: { type: 'text', wixId: 'phone', required: false },
            source: { type: 'text', wixId: 'source', required: true },
            leadType: { type: 'text', wixId: 'leadType', required: false },
            projectId: { type: 'text', wixId: 'projectId', required: false },
            notes: { type: 'text', wixId: 'notes', required: false },
            status: { type: 'text', wixId: 'status', required: true },
            createdAt: { type: 'date', wixId: 'createdAt', required: false },
            quoteTotal: { type: 'number', wixId: 'quoteTotal', required: false },
            assignedTo: { type: 'text', wixId: 'assignedTo', required: false },
            projectImage: { type: 'text', wixId: 'projectImage', required: false },
            actions: { type: 'text', wixId: 'actions', required: false },
            projectType: { type: 'text', wixId: 'projectType', required: false }
        }
    },

    // Customers Collection
    Customers: {
        collectionId: 'Customers',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            name: { type: 'text', wixId: 'name', required: true },
            email: { type: 'text', wixId: 'email', required: true },
            phone1: { type: 'text', wixId: 'phone1', required: false },
            phone2: { type: 'text', wixId: 'phone2', required: false },
            addressStreet: { type: 'text', wixId: 'address_street', required: false },
            addressCity: { type: 'text', wixId: 'address_city', required: false },
            addressState: { type: 'text', wixId: 'address_state', required: false },
            addressZip: { type: 'text', wixId: 'address_zip', required: false },
            leadSource: { type: 'text', wixId: 'leadSource', required: false },
            leadStatus: { type: 'text', wixId: 'leadStatus', required: false },
            claimNumber: { type: 'text', wixId: 'claimNumber', required: false },
            notes: { type: 'text', wixId: 'notes', required: false },
            dateCreated: { type: 'date', wixId: 'dateCreated', required: false }
        }
    },

    // Quotes Collection
    Quotes: {
        collectionId: 'Quotes',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            quoteId: { type: 'text', wixId: 'quoteId', required: true },
            customerInfo: { type: 'object', wixId: 'customerInfo', required: true },
            windows: { type: 'array', wixId: 'windows', required: true },
            totals: { type: 'object', wixId: 'totals', required: true },
            status: { type: 'text', wixId: 'status', required: true },
            source: { type: 'text', wixId: 'source', required: false },
            createdDate: { type: 'date', wixId: 'createdDate', required: false },
            expirationDate: { type: 'date', wixId: 'expirationDate', required: false },
            emailSent: { type: 'boolean', wixId: 'emailSent', required: false },
            emailSentDate: { type: 'date', wixId: 'emailSentDate', required: false },
            lastModifiedDate: { type: 'date', wixId: 'lastModifiedDate', required: false }
        }
    },

    // Quote Items Collection
    QuoteItems: {
        collectionId: 'QuoteItems',
        fields: {
            quoteId: { type: 'text', wixId: 'quoteId', required: true },
            itemNumber: { type: 'number', wixId: 'itemNumber', required: true },
            locationName: { type: 'text', wixId: 'locationName', required: false },
            locationId: { type: 'text', wixId: 'locationId', required: false },
            windowType: { type: 'text', wixId: 'windowType', required: true },
            brand: { type: 'text', wixId: 'brand', required: true },
            material: { type: 'text', wixId: 'material', required: true },
            width: { type: 'number', wixId: 'width', required: true },
            height: { type: 'number', wixId: 'height', required: true },
            universalInches: { type: 'number', wixId: 'universalInches', required: false },
            quantity: { type: 'number', wixId: 'quantity', required: true },
            unitPrice: { type: 'number', wixId: 'unitPrice', required: true },
            totalPrice: { type: 'number', wixId: 'totalPrice', required: true },
            laborCost: { type: 'number', wixId: 'laborCost', required: false },
            materialCost: { type: 'number', wixId: 'materialCost', required: false },
            glassOptions: { type: 'text', wixId: 'glassOptions', required: false },
            notes: { type: 'text', wixId: 'notes', required: false },
            uploadedImage: { type: 'text', wixId: 'uploadedImage', required: false },
            metaMeasureWidth: { type: 'number', wixId: 'metaMeasureWidth', required: false },
            metaMeasureHeight: { type: 'number', wixId: 'metaMeasureHeight', required: false },
            measureConfidence: { type: 'number', wixId: 'measureConfidence', required: false },
            isSubmitted: { type: 'boolean', wixId: 'isSubmitted', required: false },
            svgDiagram: { type: 'text', wixId: 'svgDiagram', required: false }
        }
    },

    // Scheduled Appointments Collection
    ScheduledAppointments: {
        collectionId: 'ScheduledAppointments',
        fields: {
            customer: { type: 'text', wixId: 'customer', required: true },
            customerEmail: { type: 'text', wixId: 'customerEmail', required: true },
            customerPhone: { type: 'text', wixId: 'customerPhone', required: false },
            appointmentDate: { type: 'date', wixId: 'appointmentDate', required: true },
            appointmentType: { type: 'text', wixId: 'appointmentType', required: true },
            notes: { type: 'text', wixId: 'notes', required: false },
            status: { type: 'text', wixId: 'status', required: true },
            relatedComparisonId: { type: 'text', wixId: 'relatedComparisonId', required: false },
            source: { type: 'text', wixId: 'source', required: false },
            assignedTo: { type: 'text', wixId: 'assignedTo', required: false },
            date: { type: 'date', wixId: 'date', required: false },
            createdDate: { type: 'date', wixId: 'createdDate', required: false },
            appointmentId: { type: 'text', wixId: 'appointmentId', required: false },
            projectType: { type: 'text', wixId: 'projectType', required: false },
            cancellationReason: { type: 'text', wixId: 'cancellationReason', required: false },
            completionNotes: { type: 'text', wixId: 'completionNotes', required: false },
            completedDate: { type: 'date', wixId: 'completedDate', required: false }
        }
    },

    // Training Certificates Collection
    TrainingCertificates: {
        collectionId: 'TrainingCertificates',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            userId: { type: 'text', wixId: 'userId', required: true },
            moduleId: { type: 'text', wixId: 'moduleId', required: true },
            certificateId: { type: 'text', wixId: 'certificateId', required: true },
            issuedDate: { type: 'date', wixId: 'issuedDate', required: true },
            validUntil: { type: 'date', wixId: 'validUntil', required: false },
            averageScore: { type: 'number', wixId: 'averageScore', required: false },
            completionDate: { type: 'date', wixId: 'completionDate', required: true }
        }
    },

    // Training Log Collection
    TrainingLog: {
        collectionId: 'TrainingLog',
        fields: {
            userId: { type: 'text', wixId: 'userId', required: true },
            sessionId: { type: 'text', wixId: 'sessionId', required: true },
            timeStamp: { type: 'date', wixId: 'timeStamp', required: true },
            activityType: { type: 'text', wixId: 'activityType', required: true },
            details: { type: 'text', wixId: 'details', required: false },
            pageUrl: { type: 'text', wixId: 'pageUrl', required: false },
            activity: { type: 'text', wixId: 'activity', required: false }
        }
    },

    // Training Progress Collection
    TrainingProgress: {
        collectionId: 'TrainingProgress',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            userId: { type: 'text', wixId: 'userId', required: true },
            moduleId: { type: 'text', wixId: 'moduleId', required: true },
            status: { type: 'text', wixId: 'status', required: true },
            completionDate: { type: 'date', wixId: 'completionDate', required: false },
            lastAccessed: { type: 'date', wixId: 'lastAccessed', required: false },
            progressData: { type: 'object', wixId: 'progressData', required: false },
            sessionId: { type: 'text', wixId: 'sessionId', required: false },
            startDate: { type: 'date', wixId: 'startDate', required: false },
            scenariosCompleted: { type: 'number', wixId: 'scenariosCompleted', required: false },
            averageScore: { type: 'number', wixId: 'averageScore', required: false },
            totalTimeSpent: { type: 'number', wixId: 'totalTimeSpent', required: false },
            completedModules: { type: 'array', wixId: 'completedModules', required: false },
            achievements: { type: 'array', wixId: 'achievements', required: false },
            lastActivity: { type: 'date', wixId: 'lastActivity', required: false }
        }
    },

    // Training Scores Collection
    TrainingScores: {
        collectionId: 'TrainingScores',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            userId: { type: 'text', wixId: 'userId', required: true },
            scenarioId: { type: 'text', wixId: 'scenarioId', required: true }
        }
    },

    // Referrals Collection
    Referrals: {
        collectionId: 'Referrals',
        fields: {
            referrerName: { type: 'text', wixId: 'referrerName', required: true },
            referrerEmail: { type: 'text', wixId: 'referrerEmail', required: true },
            friendName: { type: 'text', wixId: 'friendName', required: true },
            friendEmail: { type: 'text', wixId: 'friendEmail', required: true },
            referralDate: { type: 'date', wixId: 'referralDate', required: true },
            referralStatus: { type: 'text', wixId: 'referralStatus', required: true },
            rewardIssued: { type: 'boolean', wixId: 'rewardIssued', required: false },
            notes: { type: 'text', wixId: 'notes', required: false },
            referralImage: { type: 'text', wixId: 'referralImage', required: false }
        }
    },

    // Projects Collection
    Projects: {
        collectionId: 'Projects',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            projectId: { type: 'text', wixId: 'projectId', required: true },
            customerName: { type: 'text', wixId: 'customerName', required: true },
            customerEmail: { type: 'text', wixId: 'customerEmail', required: true },
            customerPhone: { type: 'text', wixId: 'customerPhone', required: false },
            projectAddress: { type: 'text', wixId: 'projectAddress', required: false },
            projectType: { type: 'text', wixId: 'projectType', required: true },
            startDate: { type: 'date', wixId: 'startDate', required: false },
            estimatedCompletion: { type: 'date', wixId: 'estimatedCompletion', required: false },
            totalValue: { type: 'number', wixId: 'totalValue', required: false },
            windowCount: { type: 'number', wixId: 'windowCount', required: false },
            notes: { type: 'text', wixId: 'notes', required: false },
            createdDate: { type: 'date', wixId: 'createdDate', required: false },
            lastModified: { type: 'date', wixId: 'lastModified', required: false },
            quoteId: { type: 'text', wixId: 'quoteId', required: false },
            status: { type: 'text', wixId: 'status', required: true }
        }
    },

    // Quote Activities Collection
    QuoteActivities: {
        collectionId: 'QuoteActivities',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            quoteId: { type: 'text', wixId: 'quoteId', required: true },
            actions: { type: 'text', wixId: 'actions', required: true },
            details: { type: 'text', wixId: 'details', required: false },
            timeStamp: { type: 'date', wixId: 'timeStamp', required: true }
        }
    },

    // Pricing Config Collection
    PricingConfig: {
        collectionId: 'PricingConfig',
        fields: {
            basePrice: { type: 'number', wixId: 'basePrice', required: true },
            saleMarkupPercentage: { type: 'number', wixId: 'saleMarkupPercentage', required: false },
            taxRate: { type: 'number', wixId: 'taxRate', required: false },
            laborMultiplier: { type: 'number', wixId: 'laborMultiplier', required: false },
            installationBasePrice: { type: 'number', wixId: 'installationBasePrice', required: false }
        }
    },

    // Materials Collection
    Materials: {
        collectionId: 'Materials',
        fields: {
            materialType: { type: 'text', wixId: 'materialType', required: true },
            materialMultiplier: { type: 'number', wixId: 'materialMultiplier', required: true },
            orderRank: { type: 'number', wixId: 'orderRank', required: false },
            uiBaseAverage: { type: 'number', wixId: 'uiBaseAverage', required: false }
        }
    },

    // Leads Pipeline Collection
    LeadsPipeline: {
        collectionId: 'LeadsPipeline',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            name: { type: 'text', wixId: 'name', required: true },
            customerEmail: { type: 'text', wixId: 'customerEmail', required: true },
            phone1: { type: 'text', wixId: 'phone1', required: false },
            phone2: { type: 'text', wixId: 'phone2', required: false },
            addressStreet: { type: 'text', wixId: 'address_street', required: false },
            addressCity: { type: 'text', wixId: 'address_city', required: false },
            addressState: { type: 'text', wixId: 'address_state', required: false },
            addressZip: { type: 'text', wixId: 'address_zip', required: false },
            leadSource: { type: 'text', wixId: 'leadSource', required: false },
            leadStatus: { type: 'text', wixId: 'leadStatus', required: false },
            claimNumber: { type: 'text', wixId: 'claimNumber', required: false },
            notes: { type: 'text', wixId: 'notes', required: false },
            dateCreated: { type: 'date', wixId: 'dateCreated', required: false },
            email: { type: 'text', wixId: 'email', required: true }
        }
    },

    // Email Log Collection
    EmailLog: {
        collectionId: 'EmailLog',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            toEmail: { type: 'text', wixId: 'toEmail', required: true },
            subject: { type: 'text', wixId: 'subject', required: true },
            type: { type: 'text', wixId: 'type', required: true },
            quoteId: { type: 'text', wixId: 'quoteId', required: false },
            status: { type: 'text', wixId: 'status', required: true },
            error: { type: 'text', wixId: 'error', required: false },
            sentAt: { type: 'date', wixId: 'sentAt', required: true }
        }
    },

    // Email Schedule Collection
    EmailSchedule: {
        collectionId: 'EmailSchedule',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            quoteId: { type: 'text', wixId: 'quoteId', required: true },
            customerEmail: { type: 'text', wixId: 'customerEmail', required: true },
            emailType: { type: 'text', wixId: 'emailType', required: true },
            scheduledFor: { type: 'date', wixId: 'scheduledFor', required: true },
            status: { type: 'text', wixId: 'status', required: true },
            createdAt: { type: 'date', wixId: 'createdAt', required: false }
        }
    },

    // Competitor Quotes Collection
    CompetitorQuotes: {
        collectionId: 'CompetitorQuotes',
        fields: {
            competitorQuotes: { type: 'text', wixId: 'competitorQuotes', required: false },
            projectId: { type: 'text', wixId: 'projectId', required: true },
            documentUrl: { type: 'text', wixId: 'documentUrl', required: false },
            competitorName: { type: 'text', wixId: 'competitorName', required: true },
            quote: { type: 'number', wixId: 'quote', required: true },
            quoteDate: { type: 'date', wixId: 'quoteDate', required: false },
            confidenceScore: { type: 'number', wixId: 'confidenceScore', required: false }
        }
    },

    // Configuration Collection
    Configuration: {
        collectionId: 'Configuration',
        fields: {
            valueType: { type: 'text', wixId: 'valueType', required: true },
            configCategory: { type: 'text', wixId: 'configCategory', required: false },
            description: { type: 'text', wixId: 'description', required: false },
            active: { type: 'boolean', wixId: 'active', required: false },
            createdDate: { type: 'date', wixId: 'createdDate', required: false },
            configValue: { type: 'text', wixId: 'configValue', required: true },
            configKey: { type: 'text', wixId: 'configKey', required: true }
        }
    },

    // Document Type Collection
    DocumentType: {
        collectionId: 'DocumentType',
        fields: {
            documentTypeName: { type: 'text', wixId: 'documentTypeName', required: true },
            description: { type: 'text', wixId: 'description', required: false },
            createdDate: { type: 'date', wixId: 'createdDate', required: false }
        }
    },

    // Comparison Items Collection
    ComparisonItems: {
        collectionId: 'ComparisonItems',
        fields: {
            title: { type: 'text', wixId: 'title', required: false },
            comparisonId: { type: 'text', wixId: 'comparisonId', required: true },
            itemDescription: { type: 'text', wixId: 'itemDescription', required: true },
            competitorValue: { type: 'number', wixId: 'competitorValue', required: false },
            competitorCost: { type: 'number', wixId: 'competitorCost', required: false },
            gfeCost: { type: 'number', wixId: 'gfeCost', required: true },
            savings: { type: 'number', wixId: 'savings', required: false },
            itemCategory: { type: 'text', wixId: 'itemCategory', required: false },
            orderRank: { type: 'number', wixId: 'orderRank', required: false },
            createdDate: { type: 'date', wixId: 'createdDate', required: false },
            gfeValue: { type: 'number', wixId: 'gfeValue', required: false }
        }
    },

    // Analytics Collection
    Analytics: {
        collectionId: 'Analytics',
        fields: {
            event: { type: 'text', wixId: 'event', required: true },
            page: { type: 'text', wixId: 'page', required: false },
            timestamp: { type: 'date', wixId: 'timestamp', required: true },
            properties: { type: 'object', wixId: 'properties', required: false },
            sessionId: { type: 'text', wixId: 'sessionId', required: true },
            userId: { type: 'text', wixId: 'userId', required: false },
            userAgent: { type: 'text', wixId: 'userAgent', required: false },
            url: { type: 'text', wixId: 'url', required: false },
            referrer: { type: 'text', wixId: 'referrer', required: false },
            leadId: { type: 'text', wixId: 'leadId', required: false },
            quoteId: { type: 'text', wixId: 'quoteId', required: false },
            eventValue: { type: 'number', wixId: 'eventValue', required: false },
            duration: { type: 'number', wixId: 'duration', required: false },
            utmSource: { type: 'text', wixId: 'utmSource', required: false },
            utmMedium: { type: 'text', wixId: 'utmMedium', required: false },
            utmCampaign: { type: 'text', wixId: 'utmCampaign', required: false },
            deviceType: { type: 'text', wixId: 'deviceType', required: false },
            errorMessage: { type: 'text', wixId: 'errorMessage', required: false },
            metadata: { type: 'object', wixId: 'metadata', required: false }
        }
    },

    // Base UI Calculator Collection
    BaseUiCalculator: {
        collectionId: 'BaseUiCalculator',
        fields: {
            goodFaithWindowCalculator: { type: 'text', wixId: 'goodFaithWindowCalculator', required: false },
            standardWidth: { type: 'number', wixId: 'standardWidth', required: true },
            standardHeight: { type: 'number', wixId: 'standardHeight', required: true },
            uiTotal: { type: 'number', wixId: 'uiTotal', required: true },
            baseUiPrice: { type: 'number', wixId: 'baseUiPrice', required: true }
        }
    },

    // Bookings Appointments Collection
    BookingsAppointments: {
        collectionId: 'BookingsAppointments',
        fields: {
            customerName: { type: 'text', wixId: 'customerName', required: true },
            email: { type: 'text', wixId: 'email', required: true },
            phoneNumber: { type: 'text', wixId: 'phoneNumber', required: false },
            selectedService: { type: 'text', wixId: 'selectedService', required: true },
            preferredDate: { type: 'date', wixId: 'preferredDate', required: true },
            preferredTime: { type: 'text', wixId: 'preferredTime', required: false },
            bookingStatus: { type: 'text', wixId: 'bookingStatus', required: true },
            internalNotes: { type: 'text', wixId: 'internalNotes', required: false },
            serviceImage: { type: 'text', wixId: 'serviceImage', required: false }
        }
    },

    // Brochure Downloads Collection
    BrochureDownloads: {
        collectionId: 'BrochureDownloads',
        fields: {
            userId: { type: 'text', wixId: 'userId', required: false },
            brochureUrl: { type: 'text', wixId: 'brochureUrl', required: true },
            brand: { type: 'text', wixId: 'brand', required: false },
            series: { type: 'text', wixId: 'series', required: false },
            material: { type: 'text', wixId: 'material', required: false },
            downloadDate: { type: 'date', wixId: 'downloadDate', required: true },
            userAgent: { type: 'text', wixId: 'userAgent', required: false },
            ipAddress: { type: 'text', wixId: 'ipAddress', required: false },
            source: { type: 'text', wixId: 'source', required: false }
        }
    },

    // AI Window Measure Service Collection
    AiWindowMeasureService: {
        collectionId: 'AiWindowMeasureService',
        fields: {
            name: { type: 'text', wixId: 'name', required: true },
            email: { type: 'text', wixId: 'email', required: true },
            phone: { type: 'text', wixId: 'phone', required: false },
            projectType: { type: 'text', wixId: 'projectType', required: false },
            notes: { type: 'text', wixId: 'notes', required: false },
            windowImage: { type: 'text', wixId: 'windowImage', required: false },
            width: { type: 'number', wixId: 'width', required: false },
            windowType: { type: 'text', wixId: 'windowType', required: false }
        }
    },

    // AI Logs Collection
    AiLogs: {
        collectionId: 'AiLogs',
        fields: {
            userId: { type: 'text', wixId: 'userId', required: false },
            userQuery: { type: 'text', wixId: 'userQuery', required: true },
            aiResponse: { type: 'text', wixId: 'aiResponse', required: true },
            responseTime: { type: 'number', wixId: 'responseTime', required: false },
            timestamp: { type: 'date', wixId: 'timestamp', required: true },
            confidenceScore: { type: 'number', wixId: 'confidenceScore', required: false },
            querySource: { type: 'text', wixId: 'querySource', required: false },
            sessionId: { type: 'text', wixId: 'sessionId', required: false }
        }
    }
};

/**
 * Field type mappings for validation
 */
export const FIELD_TYPES = {
    text: 'string',
    number: 'number',
    boolean: 'boolean',
    date: 'date',
    array: 'array',
    object: 'object'
};

/**
 * Get collection configuration by name
 * @param {string} collectionName - Name of the collection
 * @returns {object|null} - Collection configuration
 */
export function getCollectionConfig(collectionName) {
    return COLLECTIONS_CONFIG[collectionName] || null;
}

/**
 * Get field configuration for a specific collection and field
 * @param {string} collectionName - Name of the collection
 * @param {string} fieldName - Name of the field
 * @returns {object|null} - Field configuration
 */
export function getFieldConfig(collectionName, fieldName) {
    const collection = getCollectionConfig(collectionName);
    return collection?.fields?.[fieldName] || null;
}

/**
 * Get all required fields for a collection
 * @param {string} collectionName - Name of the collection
 * @returns {Array} - Array of required field names
 */
export function getRequiredFields(collectionName) {
    const collection = getCollectionConfig(collectionName);
    if (!collection) return [];
    
    return Object.keys(collection.fields).filter(
        fieldName => collection.fields[fieldName].required
    );
}

/**
 * Validate field value against its type
 * @param {any} value - Value to validate
 * @param {string} type - Expected type
 * @returns {boolean} - Is valid
 */
export function validateFieldType(value, type) {
    switch (type) {
        case 'text':
            return typeof value === 'string';
        case 'number':
            return typeof value === 'number' && !isNaN(value);
        case 'boolean':
            return typeof value === 'boolean';
        case 'date':
            return value instanceof Date || !isNaN(Date.parse(value));
        case 'array':
            return Array.isArray(value);
        case 'object':
            return typeof value === 'object' && value !== null && !Array.isArray(value);
        default:
            return true;
    }
}

/**
 * Sanitize text field to remove control characters
 * @param {string} text - Text to sanitize
 * @returns {string} - Sanitized text
 */
export function sanitizeTextField(text) {
    if (typeof text !== 'string') return text;
    return text.replace(CONTROL_CHARS_REGEX, '');
}

/**
 * Map frontend field names to Wix field IDs
 * @param {string} collectionName - Name of the collection
 * @param {object} data - Data with frontend field names
 * @returns {object} - Data with Wix field IDs
 */
export function mapToWixFields(collectionName, data) {
    const collection = getCollectionConfig(collectionName);
    if (!collection) return data;
    
    const mappedData = {};
    
    Object.keys(data).forEach(fieldName => {
        const fieldConfig = collection.fields[fieldName];
        if (fieldConfig) {
            const wixId = fieldConfig.wixId || fieldName;
            mappedData[wixId] = data[fieldName];
        } else {
            // Keep unmapped fields as-is
            mappedData[fieldName] = data[fieldName];
        }
    });
    
    return mappedData;
}

/**
 * Map Wix field IDs to frontend field names
 * @param {string} collectionName - Name of the collection
 * @param {object} data - Data with Wix field IDs
 * @returns {object} - Data with frontend field names
 */
export function mapFromWixFields(collectionName, data) {
    const collection = getCollectionConfig(collectionName);
    if (!collection) return data;
    
    const mappedData = {};
    
    // Create reverse mapping
    const reverseMapping = {};
    Object.keys(collection.fields).forEach(fieldName => {
        const wixId = collection.fields[fieldName].wixId || fieldName;
        reverseMapping[wixId] = fieldName;
    });
    
    Object.keys(data).forEach(wixId => {
        const fieldName = reverseMapping[wixId] || wixId;
        mappedData[fieldName] = data[wixId];
    });
    
    return mappedData;
}

/**
 * Get all collection names
 * @returns {Array} - Array of collection names
 */
export function getAllCollectionNames() {
    return Object.keys(COLLECTIONS_CONFIG);
}

/**
 * Validate data against collection schema
 * @param {string} collectionName - Name of the collection
 * @param {object} data - Data to validate
 * @returns {object} - Validation result
 */
export function validateCollectionData(collectionName, data) {
    const collection = getCollectionConfig(collectionName);
    if (!collection) {
        return { isValid: false, errors: [`Unknown collection: ${collectionName}`] };
    }
    
    const errors = [];
    const requiredFields = getRequiredFields(collectionName);
    
    // Check required fields
    requiredFields.forEach(fieldName => {
        if (data[fieldName] === undefined || data[fieldName] === null || data[fieldName] === '') {
            errors.push(`Required field '${fieldName}' is missing`);
        }
    });
    
    // Validate field types
    Object.keys(data).forEach(fieldName => {
        const fieldConfig = collection.fields[fieldName];
        if (fieldConfig && data[fieldName] !== undefined && data[fieldName] !== null) {
            if (!validateFieldType(data[fieldName], fieldConfig.type)) {
                errors.push(`Field '${fieldName}' has invalid type. Expected: ${fieldConfig.type}`);
            }
        }
    });
    
    return {
        isValid: errors.length === 0,
        errors
    };
}

