// backend/integrations/gfe-flf-engine.js - Fixed version
// Good Faith Exteriors - Field Label Functioning (FLF) Engine

import wixData from 'wix-data';

/**
 * Field Label Functioning (FLF) Engine
 * Maps Wix collection fields to proper functions and API endpoints
 */
export class GFEFLFEngine {
    constructor() {
        this.fieldMappings = this.initializeFieldMappings();
        this.functionRegistry = this.initializeFunctionRegistry();
    }

    /**
     * Initialize field mappings for Wix collections
     * @returns {object} - Field mapping configuration
     */
    initializeFieldMappings() {
        return {
            CustomerLeads: {
                fields: {
                    name: { type: 'text', required: true, validator: 'validateName' },
                    email: { type: 'email', required: true, validator: 'validateEmail' },
                    phone: { type: 'phone', required: false, validator: 'validatePhone' },
                    address: { type: 'text', required: false, validator: 'validateAddress' },
                    city: { type: 'text', required: false, validator: 'validateCity' },
                    state: { type: 'text', required: false, validator: 'validateState' },
                    zipCode: { type: 'text', required: false, validator: 'validateZipCode' },
                    source: { type: 'text', required: true, validator: 'validateSource' },
                    status: { type: 'text', required: true, validator: 'validateStatus' },
                    sessionId: { type: 'text', required: true, validator: 'validateSessionId' },
                    estimateData: { type: 'object', required: false, validator: 'validateEstimateData' },
                    notes: { type: 'richText', required: false, validator: 'validateNotes' }
                },
                hooks: {
                    beforeSave: 'processLeadBeforeSave',
                    afterSave: 'processLeadAfterSave',
                    beforeUpdate: 'processLeadBeforeUpdate',
                    afterUpdate: 'processLeadAfterUpdate'
                }
            },
            CustomerQuotes: {
                fields: {
                    quoteId: { type: 'text', required: true, validator: 'validateQuoteId' },
                    customerId: { type: 'text', required: true, validator: 'validateCustomerId' },
                    customerInfo: { type: 'object', required: true, validator: 'validateCustomerInfo' },
                    windowItems: { type: 'array', required: true, validator: 'validateWindowItems' },
                    subtotal: { type: 'number', required: true, validator: 'validateSubtotal' },
                    tax: { type: 'number', required: true, validator: 'validateTax' },
                    totalCost: { type: 'number', required: true, validator: 'validateTotalCost' },
                    status: { type: 'text', required: true, validator: 'validateQuoteStatus' },
                    validUntil: { type: 'date', required: true, validator: 'validateValidUntil' },
                    sessionId: { type: 'text', required: true, validator: 'validateSessionId' },
                    pdfUrl: { type: 'text', required: false, validator: 'validatePdfUrl' }
                },
                hooks: {
                    beforeSave: 'processQuoteBeforeSave',
                    afterSave: 'processQuoteAfterSave',
                    beforeUpdate: 'processQuoteBeforeUpdate',
                    afterUpdate: 'processQuoteAfterUpdate'
                }
            },
            WindowProducts: {
                fields: {
                    productId: { type: 'text', required: true, validator: 'validateProductId' },
                    brand: { type: 'text', required: true, validator: 'validateBrand' },
                    model: { type: 'text', required: true, validator: 'validateModel' },
                    windowType: { type: 'text', required: true, validator: 'validateWindowType' },
                    material: { type: 'text', required: true, validator: 'validateMaterial' },
                    pricePerWindow: { type: 'number', required: true, validator: 'validatePricePerWindow' },
                    energyRating: { type: 'text', required: false, validator: 'validateEnergyRating' },
                    warranty: { type: 'text', required: false, validator: 'validateWarranty' },
                    description: { type: 'richText', required: false, validator: 'validateDescription' },
                    imageUrl: { type: 'text', required: false, validator: 'validateImageUrl' },
                    inStock: { type: 'boolean', required: true, validator: 'validateInStock' }
                },
                hooks: {
                    beforeSave: 'processProductBeforeSave',
                    afterSave: 'processProductAfterSave'
                }
            },
            Analytics: {
                fields: {
                    eventType: { type: 'text', required: true, validator: 'validateEventType' },
                    eventData: { type: 'object', required: true, validator: 'validateEventData' },
                    sessionId: { type: 'text', required: true, validator: 'validateSessionId' },
                    userId: { type: 'text', required: false, validator: 'validateUserId' },
                    timestamp: { type: 'date', required: true, validator: 'validateTimestamp' },
                    ipAddress: { type: 'text', required: false, validator: 'validateIpAddress' },
                    userAgent: { type: 'text', required: false, validator: 'validateUserAgent' }
                },
                hooks: {
                    beforeSave: 'processAnalyticsBeforeSave',
                    afterSave: 'processAnalyticsAfterSave'
                }
            }
        };
    }

    /**
     * Initialize function registry for field processing
     * @returns {object} - Function registry
     */
    initializeFunctionRegistry() {
        return {
            validators: {
                validateName: (value) => typeof value === 'string' && value.trim().length >= 2,
                validateEmail: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
                validatePhone: (value) => /^[\+]?[1-9][\d]{0,15}$/.test(value.replace(/[\s\-\(\)]/g, '')),
                validateAddress: (value) => typeof value === 'string' && value.trim().length >= 5,
                validateCity: (value) => typeof value === 'string' && value.trim().length >= 2,
                validateState: (value) => typeof value === 'string' && value.trim().length >= 2,
                validateZipCode: (value) => /^\d{5}(-\d{4})?$/.test(value),
                validateSource: (value) => typeof value === 'string' && value.trim().length > 0,
                validateStatus: (value) => ['new', 'contacted', 'qualified', 'quoted', 'closed', 'lost'].includes(value),
                validateSessionId: (value) => typeof value === 'string' && value.length > 0,
                validateEstimateData: (value) => typeof value === 'object' && value !== null,
                validateNotes: (value) => typeof value === 'string',
                validateQuoteId: (value) => typeof value === 'string' && value.startsWith('quote_'),
                validateCustomerId: (value) => typeof value === 'string' && value.length > 0,
                validateCustomerInfo: (value) => typeof value === 'object' && value.email,
                validateWindowItems: (value) => Array.isArray(value) && value.length > 0,
                validateSubtotal: (value) => typeof value === 'number' && value >= 0,
                validateTax: (value) => typeof value === 'number' && value >= 0,
                validateTotalCost: (value) => typeof value === 'number' && value > 0,
                validateQuoteStatus: (value) => ['draft', 'sent', 'accepted', 'rejected', 'expired'].includes(value),
                validateValidUntil: (value) => value instanceof Date && value > new Date(),
                validatePdfUrl: (value) => typeof value === 'string' && value.startsWith('http'),
                validateProductId: (value) => typeof value === 'string' && value.length > 0,
                validateBrand: (value) => typeof value === 'string' && value.trim().length > 0,
                validateModel: (value) => typeof value === 'string' && value.trim().length > 0,
                validateWindowType: (value) => ['single-hung', 'double-hung', 'casement', 'sliding', 'awning', 'bay', 'bow'].includes(value),
                validateMaterial: (value) => ['vinyl', 'wood', 'aluminum', 'fiberglass', 'composite'].includes(value),
                validatePricePerWindow: (value) => typeof value === 'number' && value > 0,
                validateEnergyRating: (value) => typeof value === 'string',
                validateWarranty: (value) => typeof value === 'string',
                validateDescription: (value) => typeof value === 'string',
                validateImageUrl: (value) => typeof value === 'string' && value.startsWith('http'),
                validateInStock: (value) => typeof value === 'boolean',
                validateEventType: (value) => typeof value === 'string' && value.length > 0,
                validateEventData: (value) => typeof value === 'object' && value !== null,
                validateUserId: (value) => typeof value === 'string',
                validateTimestamp: (value) => value instanceof Date,
                validateIpAddress: (value) => /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(value),
                validateUserAgent: (value) => typeof value === 'string'
            },
            processors: {
                processLeadBeforeSave: (data) => {
                    data.createdDate = new Date();
                    data.lastUpdated = new Date();
                    if (!data.status) data.status = 'new';
                    return data;
                },
                processLeadAfterSave: (data) => {
                    console.log('Lead saved:', data._id);
                    return data;
                },
                processLeadBeforeUpdate: (data) => {
                    data.lastUpdated = new Date();
                    return data;
                },
                processLeadAfterUpdate: (data) => {
                    console.log('Lead updated:', data._id);
                    return data;
                },
                processQuoteBeforeSave: (data) => {
                    data.createdDate = new Date();
                    data.lastUpdated = new Date();
                    if (!data.status) data.status = 'draft';
                    if (!data.validUntil) {
                        const validUntil = new Date();
                        validUntil.setDate(validUntil.getDate() + 30); // 30 days validity
                        data.validUntil = validUntil;
                    }
                    return data;
                },
                processQuoteAfterSave: (data) => {
                    console.log('Quote saved:', data._id);
                    return data;
                },
                processQuoteBeforeUpdate: (data) => {
                    data.lastUpdated = new Date();
                    return data;
                },
                processQuoteAfterUpdate: (data) => {
                    console.log('Quote updated:', data._id);
                    return data;
                },
                processProductBeforeSave: (data) => {
                    data.createdDate = new Date();
                    data.lastUpdated = new Date();
                    return data;
                },
                processProductAfterSave: (data) => {
                    console.log('Product saved:', data._id);
                    return data;
                },
                processAnalyticsBeforeSave: (data) => {
                    if (!data.timestamp) data.timestamp = new Date();
                    return data;
                },
                processAnalyticsAfterSave: (data) => {
                    console.log('Analytics event saved:', data._id);
                    return data;
                }
            }
        };
    }

    /**
     * Validate data against collection field mappings
     * @param {string} collectionName - Name of the collection
     * @param {object} data - Data to validate
     * @returns {object} - Validation result
     */
    validateData(collectionName, data) {
        const mapping = this.fieldMappings[collectionName];
        if (!mapping) {
            return { isValid: false, errors: [`Unknown collection: ${collectionName}`] };
        }

        const errors = [];
        const fields = mapping.fields;

        // Check required fields
        Object.keys(fields).forEach(fieldName => {
            const fieldConfig = fields[fieldName];
            const value = data[fieldName];

            if (fieldConfig.required && (value === undefined || value === null || value === '')) {
                errors.push(`Field '${fieldName}' is required`);
                return;
            }

            if (value !== undefined && value !== null && fieldConfig.validator) {
                const validator = this.functionRegistry.validators[fieldConfig.validator];
                if (validator && !validator(value)) {
                    errors.push(`Field '${fieldName}' has invalid value`);
                }
            }
        });

        return {
            isValid: errors.length === 0,
            errors
        };
    }

    /**
     * Process data before save operation
     * @param {string} collectionName - Name of the collection
     * @param {object} data - Data to process
     * @returns {object} - Processed data
     */
    processBeforeSave(collectionName, data) {
        const mapping = this.fieldMappings[collectionName];
        if (!mapping || !mapping.hooks.beforeSave) {
            return data;
        }

        const processor = this.functionRegistry.processors[mapping.hooks.beforeSave];
        return processor ? processor(data) : data;
    }

    /**
     * Process data after save operation
     * @param {string} collectionName - Name of the collection
     * @param {object} data - Saved data
     * @returns {object} - Processed data
     */
    processAfterSave(collectionName, data) {
        const mapping = this.fieldMappings[collectionName];
        if (!mapping || !mapping.hooks.afterSave) {
            return data;
        }

        const processor = this.functionRegistry.processors[mapping.hooks.afterSave];
        return processor ? processor(data) : data;
    }

    /**
     * Process data before update operation
     * @param {string} collectionName - Name of the collection
     * @param {object} data - Data to process
     * @returns {object} - Processed data
     */
    processBeforeUpdate(collectionName, data) {
        const mapping = this.fieldMappings[collectionName];
        if (!mapping || !mapping.hooks.beforeUpdate) {
            return data;
        }

        const processor = this.functionRegistry.processors[mapping.hooks.beforeUpdate];
        return processor ? processor(data) : data;
    }

    /**
     * Process data after update operation
     * @param {string} collectionName - Name of the collection
     * @param {object} data - Updated data
     * @returns {object} - Processed data
     */
    processAfterUpdate(collectionName, data) {
        const mapping = this.fieldMappings[collectionName];
        if (!mapping || !mapping.hooks.afterUpdate) {
            return data;
        }

        const processor = this.functionRegistry.processors[mapping.hooks.afterUpdate];
        return processor ? processor(data) : data;
    }

    /**
     * Get field configuration for a collection
     * @param {string} collectionName - Name of the collection
     * @returns {object} - Field configuration
     */
    getFieldConfig(collectionName) {
        return this.fieldMappings[collectionName] || null;
    }

    /**
     * Register custom validator
     * @param {string} name - Validator name
     * @param {function} validator - Validator function
     */
    registerValidator(name, validator) {
        this.functionRegistry.validators[name] = validator;
    }

    /**
     * Register custom processor
     * @param {string} name - Processor name
     * @param {function} processor - Processor function
     */
    registerProcessor(name, processor) {
        this.functionRegistry.processors[name] = processor;
    }
}

// Create singleton instance
const gfeFLFEngine = new GFEFLFEngine();

// Export the engine instance and utility functions
export default gfeFLFEngine;

export function validateCollectionData(collectionName, data) {
    return gfeFLFEngine.validateData(collectionName, data);
}

export function processDataBeforeSave(collectionName, data) {
    return gfeFLFEngine.processBeforeSave(collectionName, data);
}

export function processDataAfterSave(collectionName, data) {
    return gfeFLFEngine.processAfterSave(collectionName, data);
}

export function processDataBeforeUpdate(collectionName, data) {
    return gfeFLFEngine.processBeforeUpdate(collectionName, data);
}

export function processDataAfterUpdate(collectionName, data) {
    return gfeFLFEngine.processAfterUpdate(collectionName, data);
}

export function getCollectionFieldConfig(collectionName) {
    return gfeFLFEngine.getFieldConfig(collectionName);
}

