/**
 * ========================================================================
 * GFE WINDOW PRODUCTS SERVICE - VELO BACKEND
 * ========================================================================
 * Handles window products data, filtering, and recommendations
 * File: backend/gfe-products-service.web.js
 */

import { ok, badRequest, serverError } from 'wix-http-functions';
import wixData from 'wix-data';

/**
 * Get GFE window products
 * GET /api/products
 */
export async function get_products(request) {
    try {
        const { query } = request;
        const brand = query.brand;
        const windowType = query.windowType;
        const material = query.material;
        const priceRange = query.priceRange;
        
        let queryBuilder = wixData.query('WindowProducts')
            .limit(100);
        
        // Apply filters
        if (brand && brand !== 'All Brands') {
            queryBuilder = queryBuilder.eq('brand', brand);
        }
        
        if (windowType && windowType !== 'All Types') {
            queryBuilder = queryBuilder.eq('windowType', windowType);
        }
        
        if (material && material !== 'All Materials') {
            queryBuilder = queryBuilder.eq('material', material);
        }
        
        const results = await queryBuilder.find();
        
        // Filter by price range if specified
        let filteredProducts = results.items;
        if (priceRange && priceRange !== 'All Prices') {
            filteredProducts = filterByPriceRange(results.items, priceRange);
        }
        
        // Only return GFE products
        const gfeProducts = filteredProducts.filter(product => 
            isGFEProduct(product)
        );
        
        return ok({
            products: gfeProducts,
            totalCount: gfeProducts.length,
            filters: {
                brands: getUniqueBrands(gfeProducts),
                windowTypes: getUniqueWindowTypes(gfeProducts),
                materials: getUniqueMaterials(gfeProducts),
                priceRange: getPriceRange(gfeProducts)
            }
        });
        
    } catch (error) {
        console.error('Get products error:', error);
        return serverError({
            error: 'Failed to retrieve products'
        });
    }
}

/**
 * Get product recommendations
 * POST /api/products/recommendations
 */
export async function post_recommendations(request) {
    try {
        const requestData = await request.body.json();
        const { windowType, budget, preferences } = requestData;
        
        // Query products based on criteria
        let queryBuilder = wixData.query('WindowProducts')
            .limit(50);
        
        if (windowType) {
            queryBuilder = queryBuilder.eq('windowType', windowType);
        }
        
        const results = await queryBuilder.find();
        
        // Filter to GFE products only
        const gfeProducts = results.items.filter(product => 
            isGFEProduct(product)
        );
        
        // Apply recommendation logic
        const recommendations = generateRecommendations(gfeProducts, {
            windowType,
            budget,
            preferences
        });
        
        return ok({
            recommendations: recommendations,
            totalCount: recommendations.length
        });
        
    } catch (error) {
        console.error('Recommendations error:', error);
        return serverError({
            error: 'Failed to generate recommendations'
        });
    }
}

/**
 * Check if product is a GFE product
 */
function isGFEProduct(product) {
    const gfeBrands = ['Provia', 'Marvin', 'Pella', 'Windsor'];
    const gfeSeries = ['Endure', 'Signature Ultimate', '250 Series', 'Next Dimension Classic'];
    
    return gfeBrands.includes(product.brand) && 
           gfeSeries.some(series => product.series && product.series.includes(series));
}

/**
 * Filter products by price range
 */
function filterByPriceRange(products, priceRange) {
    const ranges = {
        '$0 - $500': { min: 0, max: 500 },
        '$500 - $800': { min: 500, max: 800 },
        '$800 - $1,000': { min: 800, max: 1000 },
        '$1,000+': { min: 1000, max: Infinity }
    };
    
    const range = ranges[priceRange];
    if (!range) return products;
    
    return products.filter(product => {
        const price = parseFloat(product.basePrice?.replace(/[$,]/g, '') || 0);
        return price >= range.min && price <= range.max;
    });
}

/**
 * Generate product recommendations
 */
function generateRecommendations(products, criteria) {
    let scored = products.map(product => ({
        ...product,
        score: calculateRecommendationScore(product, criteria)
    }));
    
    // Sort by score (highest first)
    scored.sort((a, b) => b.score - a.score);
    
    // Return top 3 recommendations
    return scored.slice(0, 3).map(item => {
        const { score, ...product } = item;
        return {
            ...product,
            recommendationReason: getRecommendationReason(product, criteria, score)
        };
    });
}

/**
 * Calculate recommendation score
 */
function calculateRecommendationScore(product, criteria) {
    let score = 50; // Base score
    
    // Window type match
    if (criteria.windowType && product.windowType === criteria.windowType) {
        score += 30;
    }
    
    // Budget considerations
    if (criteria.budget) {
        const price = parseFloat(product.basePrice?.replace(/[$,]/g, '') || 0);
        const budget = parseFloat(criteria.budget);
        
        if (price <= budget) {
            score += 20;
        } else if (price <= budget * 1.1) {
            score += 10; // Slightly over budget
        }
    }
    
    // Preferences
    if (criteria.preferences) {
        if (criteria.preferences.includes('energy-efficient') && 
            product.description?.toLowerCase().includes('energy')) {
            score += 15;
        }
        
        if (criteria.preferences.includes('premium') && 
            product.brand === 'Marvin') {
            score += 10;
        }
        
        if (criteria.preferences.includes('value') && 
            (product.brand === 'Pella' || product.brand === 'Windsor')) {
            score += 10;
        }
    }
    
    return score;
}

/**
 * Get recommendation reason
 */
function getRecommendationReason(product, criteria, score) {
    const reasons = [];
    
    if (criteria.windowType && product.windowType === criteria.windowType) {
        reasons.push(`Perfect match for ${criteria.windowType} windows`);
    }
    
    if (criteria.budget) {
        const price = parseFloat(product.basePrice?.replace(/[$,]/g, '') || 0);
        const budget = parseFloat(criteria.budget);
        
        if (price <= budget) {
            reasons.push('Within your budget');
        }
    }
    
    if (product.brand === 'Marvin') {
        reasons.push('Premium quality and craftsmanship');
    } else if (product.brand === 'Provia') {
        reasons.push('Excellent durability and performance');
    } else if (product.brand === 'Pella') {
        reasons.push('Great value and energy efficiency');
    } else if (product.brand === 'Windsor') {
        reasons.push('Reliable performance at competitive price');
    }
    
    return reasons.join(', ') || 'Recommended based on your criteria';
}

/**
 * Utility functions for filters
 */
function getUniqueBrands(products) {
    return [...new Set(products.map(p => p.brand))].filter(Boolean);
}

function getUniqueWindowTypes(products) {
    return [...new Set(products.map(p => p.windowType))].filter(Boolean);
}

function getUniqueMaterials(products) {
    return [...new Set(products.map(p => p.material))].filter(Boolean);
}

function getPriceRange(products) {
    const prices = products
        .map(p => parseFloat(p.basePrice?.replace(/[$,]/g, '') || 0))
        .filter(p => p > 0);
    
    if (prices.length === 0) return { min: 0, max: 0 };
    
    return {
        min: Math.min(...prices),
        max: Math.max(...prices)
    };
}

