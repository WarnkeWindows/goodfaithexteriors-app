/**
 * ========================================================================
 * GFE LEAD MANAGEMENT SERVICE - VELO BACKEND
 * ========================================================================
 * Handles lead capture, validation, and CRM integration for Good Faith Exteriors
 * File: backend/gfe-lead-service.web.js
 */

import { ok, badRequest, serverError } from 'wix-http-functions';
import wixData from 'wix-data';
import wixCrm from 'wix-crm-backend';

/**
 * Lead capture endpoint
 * POST /api/leads
 */
export async function post_leads(request) {
    try {
        const leadData = await request.body.json();
        
        // Validate required fields
        const validation = validateLeadData(leadData);
        if (!validation.isValid) {
            return badRequest({
                error: 'Validation failed',
                details: validation.errors
            });
        }
        
        // Process and save lead
        const processedLead = await processLeadData(leadData);
        const savedLead = await saveLeadToCRM(processedLead);
        
        // Send notifications
        await sendLeadNotifications(savedLead);
        
        return ok({
            success: true,
            leadId: savedLead._id,
            message: 'Lead captured successfully'
        });
        
    } catch (error) {
        console.error('Lead capture error:', error);
        return serverError({
            error: 'Internal server error',
            message: 'Failed to process lead'
        });
    }
}

/**
 * Get leads endpoint
 * GET /api/leads
 */
export async function get_leads(request) {
    try {
        const { query } = request;
        const page = parseInt(query.page) || 1;
        const limit = parseInt(query.limit) || 50;
        const status = query.status;
        
        let queryBuilder = wixData.query('CRMLeads')
            .limit(limit)
            .skip((page - 1) * limit)
            .descending('_createdDate');
        
        if (status) {
            queryBuilder = queryBuilder.eq('status', status);
        }
        
        const results = await queryBuilder.find();
        
        return ok({
            leads: results.items,
            totalCount: results.totalCount,
            page: page,
            hasMore: results.hasNext()
        });
        
    } catch (error) {
        console.error('Get leads error:', error);
        return serverError({
            error: 'Failed to retrieve leads'
        });
    }
}

/**
 * Validate lead data
 */
function validateLeadData(leadData) {
    const errors = [];
    
    // Required fields validation
    if (!leadData.fullName || leadData.fullName.trim().length < 2) {
        errors.push('Full name must be at least 2 characters');
    }
    
    if (!leadData.email || !isValidEmail(leadData.email)) {
        errors.push('Valid email address is required');
    }
    
    if (!leadData.phone || !isValidPhone(leadData.phone)) {
        errors.push('Valid 10-digit phone number is required');
    }
    
    if (!leadData.projectType) {
        errors.push('Project type is required');
    }
    
    return {
        isValid: errors.length === 0,
        errors: errors
    };
}

/**
 * Process lead data before saving
 */
async function processLeadData(leadData) {
    // Calculate lead score
    let leadScore = 50; // Base score
    
    if (leadData.email) leadScore += 20;
    if (leadData.phone) leadScore += 20;
    if (leadData.projectType === 'Window Replacement') leadScore += 10;
    if (leadData.customerAddress) leadScore += 5;
    if (leadData.notes && leadData.notes.length > 20) leadScore += 5;
    
    // Determine priority based on lead score
    let priority = 3; // Low
    if (leadScore >= 80) priority = 1; // High
    else if (leadScore >= 60) priority = 2; // Medium
    
    return {
        fullName: leadData.fullName.trim(),
        email: leadData.email.toLowerCase().trim(),
        phone: cleanPhoneNumber(leadData.phone),
        projectType: leadData.projectType,
        customerAddress: leadData.customerAddress || '',
        notes: leadData.notes || '',
        source: leadData.source || 'AI Window Advisor',
        status: 'New',
        leadScore: leadScore,
        priority: priority,
        dateCreated: new Date(),
        lastUpdated: new Date()
    };
}

/**
 * Save lead to CRM collection
 */
async function saveLeadToCRM(leadData) {
    try {
        // Save to Wix Data collection
        const savedLead = await wixData.save('CRMLeads', leadData);
        
        // Also create contact in Wix CRM if not exists
        try {
            await wixCrm.createContact({
                name: {
                    first: leadData.fullName.split(' ')[0],
                    last: leadData.fullName.split(' ').slice(1).join(' ')
                },
                emails: [leadData.email],
                phones: [leadData.phone],
                addresses: leadData.customerAddress ? [{
                    street: leadData.customerAddress
                }] : [],
                labels: ['GFE Lead', leadData.projectType]
            });
        } catch (crmError) {
            console.log('CRM contact creation failed (may already exist):', crmError);
        }
        
        return savedLead;
        
    } catch (error) {
        console.error('Error saving lead:', error);
        throw error;
    }
}

/**
 * Send lead notifications
 */
async function sendLeadNotifications(leadData) {
    try {
        // You can implement email notifications here
        // Example: Send to sales team, auto-responder to customer, etc.
        console.log('Lead notification sent for:', leadData.email);
    } catch (error) {
        console.error('Notification error:', error);
        // Don't throw - notifications are not critical
    }
}

/**
 * Utility functions
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    return phoneRegex.test(phone);
}

function cleanPhoneNumber(phone) {
    return phone.replace(/\D/g, '');
}

