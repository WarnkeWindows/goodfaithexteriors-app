#!/usr/bin/env python3
"""
Good Faith Exteriors Webhook and Headless App Setup
Configures webhooks, API integrations, and headless functionality
"""

import json
import os
import requests
from typing import Dict, Any, List

class WebhookHeadlessSetup:
    def __init__(self):
        self.webhooks_dir = "/home/ubuntu/gfe-final-deployment/webhooks"
        self.headless_dir = "/home/ubuntu/gfe-final-deployment/headless-app"
        
        # Configuration
        self.config = {
            "backend_url": "https://gfe-backend-837326026335.us-central1.run.app",
            "wix_site_id": "5ec64f41-3f5e-4ba1-b9fc-018d3a8681a4",
            "wix_account_id": "10d52dd8-ec9b-4453-adbc-6293b99af499",
            "wix_app_id": "477baa33-872c-4b41-8f1f-7d5e28a684f2",
            "admin_token": "IST.eyJraWQiOiJQb3pIX2FDMiIsImFsZyI6IlJTMjU2In0.eyJkYXRhIjoie1wiaWRcIjpcIjkzZDliYjczLWY3MTAtNDcwNy1iNjQ5LWVmNDE2YWQ5YjEwYVwiLFwiaWRlbnRpdHlcIjp7XCJ0eXBlXCI6XCJhcHBsaWNhdGlvblwiLFwiaWRcIjpcIjBiNTRlNjE2LTdiZDYtNDhmNi1hYjVjLWI5YWVhNjJmZmFmY1wifSxcInRlbmFudFwiOntcInR5cGVcIjpcImFjY291bnRcIixcImlkXCI6XCIxMGQ1MmRkOC1lYzliLTQ0NTMtYWRiYy02MjkzYjk5YWY0OTlcIn19IiwiaWF0IjoxNzUxMjEyMjAwfQ.LgzLe_jVQSs4q18sXb8Mj9laOO1Y0j8CY2xAIbtgKOlOB40B3sOgDon3BoVD-NQD8VFa5cMfAweX-rrznwP6DEhdi7DeQOnE7kPOv-HOzYdcsoWpAK-r8ln4cK6zBIJ_gr_Nd6f7IglNwUUX4LKoxZngyEwvL2-1HzI6Aamuxu0_OfgerNT0aULer61By8LfPz1cvOTsWQMF6CFAkNeFPn5KJ6zqYbb4KbXKdtdj4z_61aTzdU1uU5dmxvFI29OZvFi8XtA5vIvJJTS5nfrImynZqARzk6HalCjNBs3xbz2TYFs51fQmHyLTK8Sy_I5ZyAuRnPv0Eh4kWdkJhZQtbQ"
        }
        
        print(f"🔗 Initializing Webhook and Headless App Setup for Good Faith Exteriors")
        print(f"📁 Webhooks Directory: {self.webhooks_dir}")
        print(f"📱 Headless App Directory: {self.headless_dir}")

    def create_directories(self):
        """Create directory structure for webhooks and headless app"""
        print("\n📁 Creating Directory Structure...")
        
        # Create main directories
        os.makedirs(self.webhooks_dir, exist_ok=True)
        os.makedirs(self.headless_dir, exist_ok=True)
        
        # Create subdirectories
        webhook_subdirs = [
            "handlers",
            "configurations",
            "middleware",
            "tests"
        ]
        
        headless_subdirs = [
            "api-endpoints",
            "authentication",
            "data-sync",
            "configurations"
        ]
        
        for subdir in webhook_subdirs:
            os.makedirs(os.path.join(self.webhooks_dir, subdir), exist_ok=True)
            print(f"  📂 Created: webhooks/{subdir}")
        
        for subdir in headless_subdirs:
            os.makedirs(os.path.join(self.headless_dir, subdir), exist_ok=True)
            print(f"  📂 Created: headless-app/{subdir}")

    def create_webhook_handlers(self):
        """Create webhook handler functions"""
        print("\n🔗 Creating Webhook Handlers...")
        
        # Lead processing webhook
        lead_webhook = '''// Good Faith Exteriors - Lead Processing Webhook Handler
// Handles new lead creation and processing

import { fetch } from 'wix-fetch';
import wixData from 'wix-data';

const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";

export async function post_leadCreated(request) {
    console.log('Lead created webhook triggered');
    
    try {
        const leadData = await request.body.json();
        console.log('Lead data received:', leadData);
        
        // Process lead data
        const processedLead = await processNewLead(leadData);
        
        // Send to backend for additional processing
        await sendToBackend('/webhooks/lead-created', processedLead);
        
        // Send notifications
        await sendLeadNotifications(processedLead);
        
        return {
            status: 200,
            body: {
                success: true,
                message: 'Lead processed successfully',
                leadId: processedLead.leadId
            }
        };
        
    } catch (error) {
        console.error('Lead webhook error:', error);
        return {
            status: 500,
            body: {
                success: false,
                error: error.message
            }
        };
    }
}

async function processNewLead(leadData) {
    // Calculate lead score
    const leadScore = calculateLeadScore(leadData);
    
    // Determine priority
    const priority = determinePriority(leadData, leadScore);
    
    // Assign to team member
    const assignedTo = await assignToTeamMember(leadData);
    
    // Set follow-up date
    const followUpDate = calculateFollowUpDate(priority);
    
    return {
        ...leadData,
        leadScore: leadScore,
        priority: priority,
        assignedTo: assignedTo,
        followUpDate: followUpDate,
        processedDate: new Date(),
        status: 'new'
    };
}

function calculateLeadScore(leadData) {
    let score = 0;
    
    // Project type scoring
    if (leadData.projectType === 'full_home_replacement') score += 50;
    else if (leadData.projectType === 'multiple_windows') score += 30;
    else if (leadData.projectType === 'single_window') score += 10;
    
    // Estimated value scoring
    if (leadData.estimatedProjectValue > 10000) score += 40;
    else if (leadData.estimatedProjectValue > 5000) score += 25;
    else if (leadData.estimatedProjectValue > 1000) score += 10;
    
    // Source scoring
    if (leadData.source === 'ai_estimator') score += 20;
    else if (leadData.source === 'website') score += 15;
    else if (leadData.source === 'referral') score += 25;
    
    // Contact information completeness
    if (leadData.phone && leadData.email) score += 15;
    else if (leadData.phone || leadData.email) score += 10;
    
    return Math.min(score, 100);
}

function determinePriority(leadData, leadScore) {
    if (leadScore >= 80) return 'high';
    if (leadScore >= 50) return 'medium';
    return 'low';
}

async function assignToTeamMember(leadData) {
    // Simple round-robin assignment
    // In production, this would be more sophisticated
    const teamMembers = ['sales1@goodfaithexteriors.com', 'sales2@goodfaithexteriors.com'];
    const randomIndex = Math.floor(Math.random() * teamMembers.length);
    return teamMembers[randomIndex];
}

function calculateFollowUpDate(priority) {
    const now = new Date();
    switch (priority) {
        case 'high':
            return new Date(now.getTime() + 2 * 60 * 60 * 1000); // 2 hours
        case 'medium':
            return new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours
        case 'low':
            return new Date(now.getTime() + 72 * 60 * 60 * 1000); // 72 hours
        default:
            return new Date(now.getTime() + 24 * 60 * 60 * 1000);
    }
}

async function sendToBackend(endpoint, data) {
    try {
        const response = await fetch(`${BACKEND_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'webhook-key'
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error(`Backend request failed: ${response.statusText}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Backend request error:', error);
        throw error;
    }
}

async function sendLeadNotifications(leadData) {
    try {
        // Send email notification to assigned team member
        await sendEmailNotification(leadData);
        
        // Send SMS notification for high priority leads
        if (leadData.priority === 'high') {
            await sendSMSNotification(leadData);
        }
        
        // Update dashboard/CRM
        await updateCRM(leadData);
        
    } catch (error) {
        console.error('Notification error:', error);
    }
}

async function sendEmailNotification(leadData) {
    const emailData = {
        to: leadData.assignedTo,
        subject: `New Lead: ${leadData.fullName} - ${leadData.priority.toUpperCase()} Priority`,
        template: 'new_lead_notification',
        data: leadData
    };
    
    await sendToBackend('/api/send-email', emailData);
}

async function sendSMSNotification(leadData) {
    const smsData = {
        to: '+1234567890', // Team lead phone number
        message: `HIGH PRIORITY LEAD: ${leadData.fullName} - ${leadData.projectType} - Score: ${leadData.leadScore}`
    };
    
    await sendToBackend('/api/send-sms', smsData);
}

async function updateCRM(leadData) {
    // Update external CRM system
    await sendToBackend('/api/crm-update', leadData);
}'''
        
        lead_handler_path = os.path.join(self.webhooks_dir, "handlers", "lead-webhook.js")
        with open(lead_handler_path, 'w', encoding='utf-8') as f:
            f.write(lead_webhook)
        print(f"  ✅ Lead Webhook Handler created: {lead_handler_path}")
        
        # Quote processing webhook
        quote_webhook = '''// Good Faith Exteriors - Quote Processing Webhook Handler
// Handles quote requests and generation

import { fetch } from 'wix-fetch';
import wixData from 'wix-data';

const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";

export async function post_quoteRequested(request) {
    console.log('Quote requested webhook triggered');
    
    try {
        const quoteData = await request.body.json();
        console.log('Quote data received:', quoteData);
        
        // Process quote request
        const processedQuote = await processQuoteRequest(quoteData);
        
        // Generate PDF quote
        const pdfResult = await generateQuotePDF(processedQuote);
        
        // Send quote to customer
        await sendQuoteToCustomer(processedQuote, pdfResult);
        
        // Update quote status
        await updateQuoteStatus(processedQuote.quoteId, 'sent');
        
        return {
            status: 200,
            body: {
                success: true,
                message: 'Quote processed and sent successfully',
                quoteId: processedQuote.quoteId,
                pdfUrl: pdfResult.url
            }
        };
        
    } catch (error) {
        console.error('Quote webhook error:', error);
        return {
            status: 500,
            body: {
                success: false,
                error: error.message
            }
        };
    }
}

async function processQuoteRequest(quoteData) {
    // Calculate pricing
    const pricing = await calculateQuotePricing(quoteData);
    
    // Add markup and margins
    const finalPricing = applyMarkupAndMargins(pricing);
    
    // Generate quote ID
    const quoteId = generateQuoteId();
    
    // Set expiration date
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + 30); // 30 days
    
    return {
        ...quoteData,
        quoteId: quoteId,
        pricing: finalPricing,
        totalAmount: finalPricing.total,
        expirationDate: expirationDate,
        status: 'pending',
        createdDate: new Date()
    };
}

async function calculateQuotePricing(quoteData) {
    try {
        // Send to backend for detailed pricing calculation
        const response = await fetch(`${BACKEND_URL}/api/calculate-pricing`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'webhook-key'
            },
            body: JSON.stringify(quoteData)
        });
        
        if (!response.ok) {
            throw new Error('Pricing calculation failed');
        }
        
        return await response.json();
        
    } catch (error) {
        console.error('Pricing calculation error:', error);
        
        // Fallback pricing calculation
        return calculateFallbackPricing(quoteData);
    }
}

function calculateFallbackPricing(quoteData) {
    // Simple fallback pricing logic
    let basePrice = 500; // Base window price
    
    // Adjust for window type
    if (quoteData.windowType === 'Bay') basePrice *= 2.5;
    else if (quoteData.windowType === 'Casement') basePrice *= 1.3;
    else if (quoteData.windowType === 'Double-Hung') basePrice *= 1.2;
    
    // Adjust for material
    if (quoteData.material === 'Wood') basePrice *= 1.5;
    else if (quoteData.material === 'Fiberglass') basePrice *= 1.3;
    
    // Calculate labor
    const laborCost = basePrice * 0.4;
    
    // Calculate total
    const subtotal = basePrice + laborCost;
    const tax = subtotal * 0.08; // 8% tax
    const total = subtotal + tax;
    
    return {
        basePrice: basePrice,
        laborCost: laborCost,
        subtotal: subtotal,
        tax: tax,
        total: total
    };
}

function applyMarkupAndMargins(pricing) {
    // Apply company markup
    const markup = 0.25; // 25% markup
    const markedUpTotal = pricing.total * (1 + markup);
    
    return {
        ...pricing,
        markup: pricing.total * markup,
        total: markedUpTotal
    };
}

async function generateQuotePDF(quoteData) {
    try {
        const response = await fetch(`${BACKEND_URL}/api/generate-pdf`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'webhook-key'
            },
            body: JSON.stringify({
                type: 'quote',
                data: quoteData
            })
        });
        
        if (!response.ok) {
            throw new Error('PDF generation failed');
        }
        
        return await response.json();
        
    } catch (error) {
        console.error('PDF generation error:', error);
        throw error;
    }
}

async function sendQuoteToCustomer(quoteData, pdfResult) {
    const emailData = {
        to: quoteData.customerEmail,
        subject: `Your Window Replacement Quote - ${quoteData.quoteId}`,
        template: 'quote_email',
        data: quoteData,
        attachments: [
            {
                filename: `quote_${quoteData.quoteId}.pdf`,
                url: pdfResult.url
            }
        ]
    };
    
    await sendToBackend('/api/send-email', emailData);
}

async function updateQuoteStatus(quoteId, status) {
    try {
        await wixData.update('GFE_Quotes', {
            _id: quoteId,
            status: status,
            lastModified: new Date()
        });
    } catch (error) {
        console.error('Quote status update error:', error);
    }
}

function generateQuoteId() {
    return 'Q' + Date.now() + Math.random().toString(36).substr(2, 6).toUpperCase();
}

async function sendToBackend(endpoint, data) {
    try {
        const response = await fetch(`${BACKEND_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'webhook-key'
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error(`Backend request failed: ${response.statusText}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Backend request error:', error);
        throw error;
    }
}'''
        
        quote_handler_path = os.path.join(self.webhooks_dir, "handlers", "quote-webhook.js")
        with open(quote_handler_path, 'w', encoding='utf-8') as f:
            f.write(quote_webhook)
        print(f"  ✅ Quote Webhook Handler created: {quote_handler_path}")

    def create_headless_api_endpoints(self):
        """Create headless API endpoints"""
        print("\n📱 Creating Headless API Endpoints...")
        
        # Customer portal API
        customer_api = '''// Good Faith Exteriors - Customer Portal API
// Headless API for customer portal functionality

import wixData from 'wix-data';
import { fetch } from 'wix-fetch';

const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";

// Get customer projects
export async function get_customerProjects(request) {
    try {
        const customerId = request.query.customerId;
        
        if (!customerId) {
            return {
                status: 400,
                body: { error: 'Customer ID is required' }
            };
        }
        
        // Get customer projects from Wix Data
        const projects = await wixData.query('GFE_Projects')
            .eq('customerId', customerId)
            .descending('createdDate')
            .find();
        
        // Get related quotes
        const projectIds = projects.items.map(p => p._id);
        const quotes = await wixData.query('GFE_Quotes')
            .hasSome('projectId', projectIds)
            .find();
        
        // Combine data
        const projectsWithQuotes = projects.items.map(project => ({
            ...project,
            quotes: quotes.items.filter(q => q.projectId === project._id)
        }));
        
        return {
            status: 200,
            body: {
                success: true,
                projects: projectsWithQuotes,
                totalProjects: projects.totalCount
            }
        };
        
    } catch (error) {
        console.error('Customer projects API error:', error);
        return {
            status: 500,
            body: { error: error.message }
        };
    }
}

// Get customer quotes
export async function get_customerQuotes(request) {
    try {
        const customerId = request.query.customerId;
        
        if (!customerId) {
            return {
                status: 400,
                body: { error: 'Customer ID is required' }
            };
        }
        
        const quotes = await wixData.query('GFE_Quotes')
            .eq('customerId', customerId)
            .descending('createdDate')
            .find();
        
        return {
            status: 200,
            body: {
                success: true,
                quotes: quotes.items,
                totalQuotes: quotes.totalCount
            }
        };
        
    } catch (error) {
        console.error('Customer quotes API error:', error);
        return {
            status: 500,
            body: { error: error.message }
        };
    }
}

// Submit customer feedback
export async function post_customerFeedback(request) {
    try {
        const feedbackData = await request.body.json();
        
        // Validate required fields
        if (!feedbackData.customerId || !feedbackData.rating || !feedbackData.comments) {
            return {
                status: 400,
                body: { error: 'Customer ID, rating, and comments are required' }
            };
        }
        
        // Save feedback to Wix Data
        const feedback = await wixData.save('GFE_CustomerFeedback', {
            ...feedbackData,
            submittedDate: new Date(),
            status: 'new'
        });
        
        // Send notification to team
        await notifyTeamOfFeedback(feedback);
        
        return {
            status: 200,
            body: {
                success: true,
                message: 'Feedback submitted successfully',
                feedbackId: feedback._id
            }
        };
        
    } catch (error) {
        console.error('Customer feedback API error:', error);
        return {
            status: 500,
            body: { error: error.message }
        };
    }
}

// Schedule appointment
export async function post_scheduleAppointment(request) {
    try {
        const appointmentData = await request.body.json();
        
        // Validate required fields
        if (!appointmentData.customerId || !appointmentData.preferredDate || !appointmentData.serviceType) {
            return {
                status: 400,
                body: { error: 'Customer ID, preferred date, and service type are required' }
            };
        }
        
        // Check availability
        const isAvailable = await checkAppointmentAvailability(appointmentData.preferredDate);
        
        if (!isAvailable) {
            return {
                status: 409,
                body: { error: 'Requested time slot is not available' }
            };
        }
        
        // Create appointment
        const appointment = await wixData.save('GFE_Appointments', {
            ...appointmentData,
            status: 'scheduled',
            createdDate: new Date()
        });
        
        // Send confirmation
        await sendAppointmentConfirmation(appointment);
        
        return {
            status: 200,
            body: {
                success: true,
                message: 'Appointment scheduled successfully',
                appointmentId: appointment._id
            }
        };
        
    } catch (error) {
        console.error('Schedule appointment API error:', error);
        return {
            status: 500,
            body: { error: error.message }
        };
    }
}

async function notifyTeamOfFeedback(feedback) {
    try {
        await fetch(`${BACKEND_URL}/api/notifications/feedback`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'api-key'
            },
            body: JSON.stringify(feedback)
        });
    } catch (error) {
        console.error('Feedback notification error:', error);
    }
}

async function checkAppointmentAvailability(preferredDate) {
    try {
        const existingAppointments = await wixData.query('GFE_Appointments')
            .eq('scheduledDate', new Date(preferredDate))
            .find();
        
        // Simple availability check - max 5 appointments per day
        return existingAppointments.totalCount < 5;
        
    } catch (error) {
        console.error('Availability check error:', error);
        return false;
    }
}

async function sendAppointmentConfirmation(appointment) {
    try {
        await fetch(`${BACKEND_URL}/api/send-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'api-key'
            },
            body: JSON.stringify({
                to: appointment.customerEmail,
                subject: 'Appointment Confirmation - Good Faith Exteriors',
                template: 'appointment_confirmation',
                data: appointment
            })
        });
    } catch (error) {
        console.error('Appointment confirmation error:', error);
    }
}'''
        
        customer_api_path = os.path.join(self.headless_dir, "api-endpoints", "customer-portal-api.js")
        with open(customer_api_path, 'w', encoding='utf-8') as f:
            f.write(customer_api)
        print(f"  ✅ Customer Portal API created: {customer_api_path}")

    def create_authentication_system(self):
        """Create authentication system for headless app"""
        print("\n🔐 Creating Authentication System...")
        
        auth_system = '''// Good Faith Exteriors - Authentication System
// Handles customer authentication for headless app

import wixData from 'wix-data';
import { fetch } from 'wix-fetch';
import wixSecretsBackend from 'wix-secrets-backend';

const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";

// Customer login
export async function post_customerLogin(request) {
    try {
        const { email, password } = await request.body.json();
        
        if (!email || !password) {
            return {
                status: 400,
                body: { error: 'Email and password are required' }
            };
        }
        
        // Authenticate customer
        const authResult = await authenticateCustomer(email, password);
        
        if (!authResult.success) {
            return {
                status: 401,
                body: { error: 'Invalid credentials' }
            };
        }
        
        // Generate session token
        const sessionToken = await generateSessionToken(authResult.customer);
        
        // Update last login
        await updateLastLogin(authResult.customer._id);
        
        return {
            status: 200,
            body: {
                success: true,
                token: sessionToken,
                customer: {
                    id: authResult.customer._id,
                    email: authResult.customer.email,
                    fullName: authResult.customer.fullName
                }
            }
        };
        
    } catch (error) {
        console.error('Customer login error:', error);
        return {
            status: 500,
            body: { error: 'Login failed' }
        };
    }
}

// Customer registration
export async function post_customerRegister(request) {
    try {
        const customerData = await request.body.json();
        
        // Validate required fields
        if (!customerData.email || !customerData.password || !customerData.fullName) {
            return {
                status: 400,
                body: { error: 'Email, password, and full name are required' }
            };
        }
        
        // Check if customer already exists
        const existingCustomer = await wixData.query('GFE_Customers')
            .eq('email', customerData.email)
            .find();
        
        if (existingCustomer.totalCount > 0) {
            return {
                status: 409,
                body: { error: 'Customer already exists' }
            };
        }
        
        // Hash password
        const hashedPassword = await hashPassword(customerData.password);
        
        // Create customer
        const customer = await wixData.save('GFE_Customers', {
            email: customerData.email,
            fullName: customerData.fullName,
            phone: customerData.phone || '',
            address: customerData.address || '',
            passwordHash: hashedPassword,
            userType: 'customer',
            registrationDate: new Date(),
            lastLogin: new Date(),
            isActive: true
        });
        
        // Send welcome email
        await sendWelcomeEmail(customer);
        
        // Generate session token
        const sessionToken = await generateSessionToken(customer);
        
        return {
            status: 201,
            body: {
                success: true,
                message: 'Customer registered successfully',
                token: sessionToken,
                customer: {
                    id: customer._id,
                    email: customer.email,
                    fullName: customer.fullName
                }
            }
        };
        
    } catch (error) {
        console.error('Customer registration error:', error);
        return {
            status: 500,
            body: { error: 'Registration failed' }
        };
    }
}

// Verify session token
export async function post_verifyToken(request) {
    try {
        const { token } = await request.body.json();
        
        if (!token) {
            return {
                status: 400,
                body: { error: 'Token is required' }
            };
        }
        
        const verification = await verifySessionToken(token);
        
        if (!verification.valid) {
            return {
                status: 401,
                body: { error: 'Invalid or expired token' }
            };
        }
        
        return {
            status: 200,
            body: {
                success: true,
                customer: verification.customer
            }
        };
        
    } catch (error) {
        console.error('Token verification error:', error);
        return {
            status: 500,
            body: { error: 'Token verification failed' }
        };
    }
}

// Password reset request
export async function post_passwordReset(request) {
    try {
        const { email } = await request.body.json();
        
        if (!email) {
            return {
                status: 400,
                body: { error: 'Email is required' }
            };
        }
        
        // Check if customer exists
        const customer = await wixData.query('GFE_Customers')
            .eq('email', email)
            .find();
        
        if (customer.totalCount === 0) {
            // Don't reveal if email exists or not
            return {
                status: 200,
                body: { message: 'If the email exists, a reset link has been sent' }
            };
        }
        
        // Generate reset token
        const resetToken = await generateResetToken(customer.items[0]);
        
        // Send reset email
        await sendPasswordResetEmail(customer.items[0], resetToken);
        
        return {
            status: 200,
            body: { message: 'Password reset link sent to your email' }
        };
        
    } catch (error) {
        console.error('Password reset error:', error);
        return {
            status: 500,
            body: { error: 'Password reset failed' }
        };
    }
}

async function authenticateCustomer(email, password) {
    try {
        const customer = await wixData.query('GFE_Customers')
            .eq('email', email)
            .eq('isActive', true)
            .find();
        
        if (customer.totalCount === 0) {
            return { success: false };
        }
        
        const customerData = customer.items[0];
        const isValidPassword = await verifyPassword(password, customerData.passwordHash);
        
        if (!isValidPassword) {
            return { success: false };
        }
        
        return {
            success: true,
            customer: customerData
        };
        
    } catch (error) {
        console.error('Authentication error:', error);
        return { success: false };
    }
}

async function hashPassword(password) {
    // In production, use proper password hashing
    // This is a simplified example
    const crypto = require('crypto');
    return crypto.createHash('sha256').update(password).digest('hex');
}

async function verifyPassword(password, hash) {
    const hashedPassword = await hashPassword(password);
    return hashedPassword === hash;
}

async function generateSessionToken(customer) {
    // Generate JWT token or similar
    // This is a simplified example
    const tokenData = {
        customerId: customer._id,
        email: customer.email,
        issued: Date.now(),
        expires: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
    };
    
    return Buffer.from(JSON.stringify(tokenData)).toString('base64');
}

async function verifySessionToken(token) {
    try {
        const tokenData = JSON.parse(Buffer.from(token, 'base64').toString());
        
        if (tokenData.expires < Date.now()) {
            return { valid: false };
        }
        
        const customer = await wixData.get('GFE_Customers', tokenData.customerId);
        
        return {
            valid: true,
            customer: {
                id: customer._id,
                email: customer.email,
                fullName: customer.fullName
            }
        };
        
    } catch (error) {
        return { valid: false };
    }
}

async function generateResetToken(customer) {
    const resetToken = Math.random().toString(36).substr(2, 32);
    
    // Save reset token to database
    await wixData.update('GFE_Customers', {
        _id: customer._id,
        resetToken: resetToken,
        resetTokenExpires: new Date(Date.now() + 60 * 60 * 1000) // 1 hour
    });
    
    return resetToken;
}

async function updateLastLogin(customerId) {
    try {
        await wixData.update('GFE_Customers', {
            _id: customerId,
            lastLogin: new Date()
        });
    } catch (error) {
        console.error('Update last login error:', error);
    }
}

async function sendWelcomeEmail(customer) {
    try {
        await fetch(`${BACKEND_URL}/api/send-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'api-key'
            },
            body: JSON.stringify({
                to: customer.email,
                subject: 'Welcome to Good Faith Exteriors',
                template: 'welcome_email',
                data: customer
            })
        });
    } catch (error) {
        console.error('Welcome email error:', error);
    }
}

async function sendPasswordResetEmail(customer, resetToken) {
    try {
        await fetch(`${BACKEND_URL}/api/send-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'api-key'
            },
            body: JSON.stringify({
                to: customer.email,
                subject: 'Password Reset - Good Faith Exteriors',
                template: 'password_reset_email',
                data: {
                    ...customer,
                    resetToken: resetToken,
                    resetUrl: `https://goodfaithexteriors.com/reset-password?token=${resetToken}`
                }
            })
        });
    } catch (error) {
        console.error('Password reset email error:', error);
    }
}'''
        
        auth_path = os.path.join(self.headless_dir, "authentication", "auth-system.js")
        with open(auth_path, 'w', encoding='utf-8') as f:
            f.write(auth_system)
        print(f"  ✅ Authentication System created: {auth_path}")

    def create_configuration_files(self):
        """Create configuration files for webhooks and headless app"""
        print("\n⚙️  Creating Configuration Files...")
        
        # Webhook configuration
        webhook_config = {
            "webhooks": {
                "lead_created": {
                    "endpoint": f"{self.config['backend_url']}/webhooks/lead-created",
                    "events": ["data.created"],
                    "collection": "GFE_Leads",
                    "handler": "handlers/lead-webhook.js",
                    "enabled": True
                },
                "quote_requested": {
                    "endpoint": f"{self.config['backend_url']}/webhooks/quote-requested",
                    "events": ["data.created"],
                    "collection": "GFE_Quotes", 
                    "handler": "handlers/quote-webhook.js",
                    "enabled": True
                },
                "project_updated": {
                    "endpoint": f"{self.config['backend_url']}/webhooks/project-updated",
                    "events": ["data.updated"],
                    "collection": "GFE_Projects",
                    "handler": "handlers/project-webhook.js",
                    "enabled": True
                }
            },
            "global_config": {
                "backend_url": self.config["backend_url"],
                "wix_site_id": self.config["wix_site_id"],
                "retry_attempts": 3,
                "timeout": 30000,
                "authentication": {
                    "type": "api_key",
                    "header": "X-API-Key"
                }
            }
        }
        
        webhook_config_path = os.path.join(self.webhooks_dir, "configurations", "webhook_config.json")
        with open(webhook_config_path, 'w') as f:
            json.dump(webhook_config, f, indent=2)
        print(f"  📄 Created: webhook_config.json")
        
        # Headless app configuration
        headless_config = {
            "app": {
                "name": "Good Faith Exteriors Headless App",
                "version": "1.0.0",
                "description": "Headless application for customer portal and API access"
            },
            "api": {
                "base_url": f"{self.config['backend_url']}/api",
                "endpoints": {
                    "customer_projects": "/customer/projects",
                    "customer_quotes": "/customer/quotes",
                    "customer_feedback": "/customer/feedback",
                    "schedule_appointment": "/customer/appointment"
                },
                "authentication": {
                    "type": "bearer_token",
                    "login_endpoint": "/auth/login",
                    "register_endpoint": "/auth/register",
                    "verify_endpoint": "/auth/verify",
                    "reset_endpoint": "/auth/reset"
                }
            },
            "features": {
                "customer_portal": True,
                "project_tracking": True,
                "quote_management": True,
                "appointment_scheduling": True,
                "feedback_system": True,
                "document_access": True
            },
            "security": {
                "cors_enabled": True,
                "rate_limiting": True,
                "request_validation": True,
                "data_encryption": True
            }
        }
        
        headless_config_path = os.path.join(self.headless_dir, "configurations", "headless_config.json")
        with open(headless_config_path, 'w') as f:
            json.dump(headless_config, f, indent=2)
        print(f"  📄 Created: headless_config.json")

    def run_webhook_headless_setup(self):
        """Run the complete webhook and headless app setup"""
        print("\n🚀 Starting Webhook and Headless App Setup...")
        print("=" * 70)
        
        # Create directories
        self.create_directories()
        
        # Create webhook handlers
        self.create_webhook_handlers()
        
        # Create headless API endpoints
        self.create_headless_api_endpoints()
        
        # Create authentication system
        self.create_authentication_system()
        
        # Create configuration files
        self.create_configuration_files()
        
        print("\n" + "=" * 70)
        print("🎉 Webhook and Headless App Setup Completed!")
        print(f"🔗 Webhooks Directory: {self.webhooks_dir}")
        print(f"📱 Headless App Directory: {self.headless_dir}")
        print(f"🌐 Backend URL: {self.config['backend_url']}")
        
        return {
            "webhooks_dir": self.webhooks_dir,
            "headless_dir": self.headless_dir,
            "config": self.config,
            "features": [
                "Lead processing webhooks",
                "Quote generation webhooks",
                "Customer portal API",
                "Authentication system",
                "Project tracking",
                "Appointment scheduling"
            ]
        }

def main():
    """Main webhook and headless setup function"""
    try:
        setup = WebhookHeadlessSetup()
        results = setup.run_webhook_headless_setup()
        
        # Save setup results
        with open('/home/ubuntu/webhook_headless_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n📋 Webhook and headless setup results saved to webhook_headless_results.json")
        return results
        
    except Exception as e:
        print(f"❌ Webhook and headless setup failed: {str(e)}")
        return {"status": "failed", "error": str(e)}

if __name__ == "__main__":
    main()

