// Good Faith Exteriors - Lead Processing Webhook Handler
// Handles new lead creation and processing

import { fetch } from 'wix-fetch';
import wixData from 'wix-data';

const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";

export async function post_leadCreated(request) {
    console.log('Lead created webhook triggered');
    
    try {
        const leadData = await request.body.json();
        console.log('Lead data received:', leadData);
        
        // Process lead data
        const processedLead = await processNewLead(leadData);
        
        // Send to backend for additional processing
        await sendToBackend('/webhooks/lead-created', processedLead);
        
        // Send notifications
        await sendLeadNotifications(processedLead);
        
        return {
            status: 200,
            body: {
                success: true,
                message: 'Lead processed successfully',
                leadId: processedLead.leadId
            }
        };
        
    } catch (error) {
        console.error('Lead webhook error:', error);
        return {
            status: 500,
            body: {
                success: false,
                error: error.message
            }
        };
    }
}

async function processNewLead(leadData) {
    // Calculate lead score
    const leadScore = calculateLeadScore(leadData);
    
    // Determine priority
    const priority = determinePriority(leadData, leadScore);
    
    // Assign to team member
    const assignedTo = await assignToTeamMember(leadData);
    
    // Set follow-up date
    const followUpDate = calculateFollowUpDate(priority);
    
    return {
        ...leadData,
        leadScore: leadScore,
        priority: priority,
        assignedTo: assignedTo,
        followUpDate: followUpDate,
        processedDate: new Date(),
        status: 'new'
    };
}

function calculateLeadScore(leadData) {
    let score = 0;
    
    // Project type scoring
    if (leadData.projectType === 'full_home_replacement') score += 50;
    else if (leadData.projectType === 'multiple_windows') score += 30;
    else if (leadData.projectType === 'single_window') score += 10;
    
    // Estimated value scoring
    if (leadData.estimatedProjectValue > 10000) score += 40;
    else if (leadData.estimatedProjectValue > 5000) score += 25;
    else if (leadData.estimatedProjectValue > 1000) score += 10;
    
    // Source scoring
    if (leadData.source === 'ai_estimator') score += 20;
    else if (leadData.source === 'website') score += 15;
    else if (leadData.source === 'referral') score += 25;
    
    // Contact information completeness
    if (leadData.phone && leadData.email) score += 15;
    else if (leadData.phone || leadData.email) score += 10;
    
    return Math.min(score, 100);
}

function determinePriority(leadData, leadScore) {
    if (leadScore >= 80) return 'high';
    if (leadScore >= 50) return 'medium';
    return 'low';
}

async function assignToTeamMember(leadData) {
    // Simple round-robin assignment
    // In production, this would be more sophisticated
    const teamMembers = ['sales1@goodfaithexteriors.com', 'sales2@goodfaithexteriors.com'];
    const randomIndex = Math.floor(Math.random() * teamMembers.length);
    return teamMembers[randomIndex];
}

function calculateFollowUpDate(priority) {
    const now = new Date();
    switch (priority) {
        case 'high':
            return new Date(now.getTime() + 2 * 60 * 60 * 1000); // 2 hours
        case 'medium':
            return new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours
        case 'low':
            return new Date(now.getTime() + 72 * 60 * 60 * 1000); // 72 hours
        default:
            return new Date(now.getTime() + 24 * 60 * 60 * 1000);
    }
}

async function sendToBackend(endpoint, data) {
    try {
        const response = await fetch(`${BACKEND_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'webhook-key'
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error(`Backend request failed: ${response.statusText}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Backend request error:', error);
        throw error;
    }
}

async function sendLeadNotifications(leadData) {
    try {
        // Send email notification to assigned team member
        await sendEmailNotification(leadData);
        
        // Send SMS notification for high priority leads
        if (leadData.priority === 'high') {
            await sendSMSNotification(leadData);
        }
        
        // Update dashboard/CRM
        await updateCRM(leadData);
        
    } catch (error) {
        console.error('Notification error:', error);
    }
}

async function sendEmailNotification(leadData) {
    const emailData = {
        to: leadData.assignedTo,
        subject: `New Lead: ${leadData.fullName} - ${leadData.priority.toUpperCase()} Priority`,
        template: 'new_lead_notification',
        data: leadData
    };
    
    await sendToBackend('/api/send-email', emailData);
}

async function sendSMSNotification(leadData) {
    const smsData = {
        to: '+1234567890', // Team lead phone number
        message: `HIGH PRIORITY LEAD: ${leadData.fullName} - ${leadData.projectType} - Score: ${leadData.leadScore}`
    };
    
    await sendToBackend('/api/send-sms', smsData);
}

async function updateCRM(leadData) {
    // Update external CRM system
    await sendToBackend('/api/crm-update', leadData);
}