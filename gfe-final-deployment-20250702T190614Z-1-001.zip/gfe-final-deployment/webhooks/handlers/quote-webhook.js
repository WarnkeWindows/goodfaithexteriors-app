// Good Faith Exteriors - Quote Processing Webhook Handler
// Handles quote requests and generation

import { fetch } from 'wix-fetch';
import wixData from 'wix-data';

const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";

export async function post_quoteRequested(request) {
    console.log('Quote requested webhook triggered');
    
    try {
        const quoteData = await request.body.json();
        console.log('Quote data received:', quoteData);
        
        // Process quote request
        const processedQuote = await processQuoteRequest(quoteData);
        
        // Generate PDF quote
        const pdfResult = await generateQuotePDF(processedQuote);
        
        // Send quote to customer
        await sendQuoteToCustomer(processedQuote, pdfResult);
        
        // Update quote status
        await updateQuoteStatus(processedQuote.quoteId, 'sent');
        
        return {
            status: 200,
            body: {
                success: true,
                message: 'Quote processed and sent successfully',
                quoteId: processedQuote.quoteId,
                pdfUrl: pdfResult.url
            }
        };
        
    } catch (error) {
        console.error('Quote webhook error:', error);
        return {
            status: 500,
            body: {
                success: false,
                error: error.message
            }
        };
    }
}

async function processQuoteRequest(quoteData) {
    // Calculate pricing
    const pricing = await calculateQuotePricing(quoteData);
    
    // Add markup and margins
    const finalPricing = applyMarkupAndMargins(pricing);
    
    // Generate quote ID
    const quoteId = generateQuoteId();
    
    // Set expiration date
    const expirationDate = new Date();
    expirationDate.setDate(expirationDate.getDate() + 30); // 30 days
    
    return {
        ...quoteData,
        quoteId: quoteId,
        pricing: finalPricing,
        totalAmount: finalPricing.total,
        expirationDate: expirationDate,
        status: 'pending',
        createdDate: new Date()
    };
}

async function calculateQuotePricing(quoteData) {
    try {
        // Send to backend for detailed pricing calculation
        const response = await fetch(`${BACKEND_URL}/api/calculate-pricing`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'webhook-key'
            },
            body: JSON.stringify(quoteData)
        });
        
        if (!response.ok) {
            throw new Error('Pricing calculation failed');
        }
        
        return await response.json();
        
    } catch (error) {
        console.error('Pricing calculation error:', error);
        
        // Fallback pricing calculation
        return calculateFallbackPricing(quoteData);
    }
}

function calculateFallbackPricing(quoteData) {
    // Simple fallback pricing logic
    let basePrice = 500; // Base window price
    
    // Adjust for window type
    if (quoteData.windowType === 'Bay') basePrice *= 2.5;
    else if (quoteData.windowType === 'Casement') basePrice *= 1.3;
    else if (quoteData.windowType === 'Double-Hung') basePrice *= 1.2;
    
    // Adjust for material
    if (quoteData.material === 'Wood') basePrice *= 1.5;
    else if (quoteData.material === 'Fiberglass') basePrice *= 1.3;
    
    // Calculate labor
    const laborCost = basePrice * 0.4;
    
    // Calculate total
    const subtotal = basePrice + laborCost;
    const tax = subtotal * 0.08; // 8% tax
    const total = subtotal + tax;
    
    return {
        basePrice: basePrice,
        laborCost: laborCost,
        subtotal: subtotal,
        tax: tax,
        total: total
    };
}

function applyMarkupAndMargins(pricing) {
    // Apply company markup
    const markup = 0.25; // 25% markup
    const markedUpTotal = pricing.total * (1 + markup);
    
    return {
        ...pricing,
        markup: pricing.total * markup,
        total: markedUpTotal
    };
}

async function generateQuotePDF(quoteData) {
    try {
        const response = await fetch(`${BACKEND_URL}/api/generate-pdf`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'webhook-key'
            },
            body: JSON.stringify({
                type: 'quote',
                data: quoteData
            })
        });
        
        if (!response.ok) {
            throw new Error('PDF generation failed');
        }
        
        return await response.json();
        
    } catch (error) {
        console.error('PDF generation error:', error);
        throw error;
    }
}

async function sendQuoteToCustomer(quoteData, pdfResult) {
    const emailData = {
        to: quoteData.customerEmail,
        subject: `Your Window Replacement Quote - ${quoteData.quoteId}`,
        template: 'quote_email',
        data: quoteData,
        attachments: [
            {
                filename: `quote_${quoteData.quoteId}.pdf`,
                url: pdfResult.url
            }
        ]
    };
    
    await sendToBackend('/api/send-email', emailData);
}

async function updateQuoteStatus(quoteId, status) {
    try {
        await wixData.update('GFE_Quotes', {
            _id: quoteId,
            status: status,
            lastModified: new Date()
        });
    } catch (error) {
        console.error('Quote status update error:', error);
    }
}

function generateQuoteId() {
    return 'Q' + Date.now() + Math.random().toString(36).substr(2, 6).toUpperCase();
}

async function sendToBackend(endpoint, data) {
    try {
        const response = await fetch(`${BACKEND_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'webhook-key'
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error(`Backend request failed: ${response.statusText}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Backend request error:', error);
        throw error;
    }
}