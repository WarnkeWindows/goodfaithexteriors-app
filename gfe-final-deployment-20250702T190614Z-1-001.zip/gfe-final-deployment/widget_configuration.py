#!/usr/bin/env python3
"""
Good Faith Exteriors Widget Configuration Script
Configures all interactive widgets and components for Wix deployment
"""

import json
import os
from typing import Dict, Any, List

class WidgetConfiguration:
    def __init__(self):
        self.widgets_dir = "/home/ubuntu/gfe-final-deployment/widgets"
        self.components_dir = "/home/ubuntu/gfe-final-deployment/html-components"
        
        # Widget configuration
        self.widget_config = {
            "backend_url": "https://gfe-backend-837326026335.us-central1.run.app",
            "wix_site_id": "5ec64f41-3f5e-4ba1-b9fc-018d3a8681a4",
            "image_assets": {
                "gfe_estimator_icon": "https://static.wixstatic.com/media/10d52d_3ae1e0c1d7e14bc29cfa14bb8e1daae3~mv2.png",
                "ai_window_measure_icon": "https://static.wixstatic.com/media/10d52d_2cdb7f6c24ff4e4794f59e90a50426a8~mv2.png",
                "landscape_logo": "https://static.wixstatic.com/media/10d52d_8f0c20132db94d0d9f695f94fda4b9eb~mv2.png",
                "square_logo": "https://static.wixstatic.com/media/10d52d_ac7573dd43a6475088253b9cebf12832~mv2.png",
                "luxury_home_bg": "https://static.wixstatic.com/media/10d52d_8dfdfdaaa9b245d8ac3ee0fa78472a7a~mv2.png",
                "gridflow_icon": "https://static.wixstatic.com/media/10d52d_a3d4503a473844d18ae66674cf9a61aa~mv2.jpg"
            },
            "brand_logos": {
                "andersen": "https://static.wixstatic.com/media/10d52d_0362f0e2607449dc807d7df305883bc9~mv2.jpeg",
                "marvin": "https://static.wixstatic.com/media/10d52d_a5381c6eee234bebb32b712a77ca9670~mv2.jpeg",
                "pella": "https://static.wixstatic.com/media/10d52d_dd63b7a12f074a90aa4b481556b9651f~mv2.jpeg",
                "provia": "https://static.wixstatic.com/media/162602_14f0d6c4e8a349d8aa87f1586bac09da~mv2.png",
                "thermo_tech": "https://static.wixstatic.com/media/10d52d_49654779eb11499f8a7ca634630787d3~mv2.jpeg"
            },
            "window_types": {
                "sliding": "https://static.wixstatic.com/media/10d52d_c77b917355a84831a094d0e48af938c9~mv2.png",
                "bay": "https://static.wixstatic.com/media/10d52d_f38d25e291c14d229d01ad26856145e5~mv2.png",
                "awning": "https://static.wixstatic.com/media/10d52d_2b2decc6c28e488d9b00d9f73c93f592~mv2.png",
                "picture": "https://static.wixstatic.com/media/10d52d_16542e06d2ce45a98f06575249fdfbd7~mv2.png",
                "single_hung": "https://static.wixstatic.com/media/10d52d_0d4dbf55951947428637bd9b385cff9d~mv2.png",
                "double_hung": "https://static.wixstatic.com/media/10d52d_b7191df42c924cb1bb1a936670cd496e~mv2.png",
                "casement": "https://static.wixstatic.com/media/10d52d_a8b2670c496343b4b231b5044f46e30b~mv2.png"
            }
        }
        
        print(f"🎨 Initializing Widget Configuration for Good Faith Exteriors")
        print(f"📁 Widgets Directory: {self.widgets_dir}")

    def create_widgets_directory(self):
        """Create widgets directory structure"""
        print("\n📁 Creating Widgets Directory Structure...")
        
        os.makedirs(self.widgets_dir, exist_ok=True)
        
        # Create subdirectories for different widget types
        widget_subdirs = [
            "interactive-components",
            "velo-integrations", 
            "api-connectors",
            "ui-elements",
            "configurations"
        ]
        
        for subdir in widget_subdirs:
            os.makedirs(os.path.join(self.widgets_dir, subdir), exist_ok=True)
            print(f"  📂 Created: {subdir}")

    def create_ai_window_estimator_widget(self):
        """Create enhanced AI Window Estimator widget"""
        print("\n🤖 Creating AI Window Estimator Widget...")
        
        widget_html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GFE AI Window Estimator Widget</title>
    <style>
        :root {{
            --primary-navy: #1A365D;
            --secondary-gold: #D4AF37;
            --accent-silver: #C0C0C0;
            --white: #FFFFFF;
            --success: #38A169;
            --error: #E53E3E;
        }}
        
        .widget-container {{
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: var(--white);
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(26, 54, 93, 0.1);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }}
        
        .widget-header {{
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, var(--primary-navy) 0%, #2D3748 100%);
            border-radius: 10px;
            color: var(--white);
        }}
        
        .widget-header h2 {{
            font-size: 1.8rem;
            margin-bottom: 10px;
        }}
        
        .upload-area {{
            border: 2px dashed var(--accent-silver);
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            cursor: pointer;
        }}
        
        .upload-area:hover {{
            border-color: var(--secondary-gold);
            background: rgba(212, 175, 55, 0.05);
        }}
        
        .upload-area.dragover {{
            border-color: var(--secondary-gold);
            background: rgba(212, 175, 55, 0.1);
        }}
        
        .upload-icon {{
            width: 64px;
            height: 64px;
            margin: 0 auto 15px;
            background: url('{self.widget_config["image_assets"]["ai_window_measure_icon"]}') center/contain no-repeat;
        }}
        
        .file-input {{
            display: none;
        }}
        
        .upload-button {{
            background: var(--secondary-gold);
            color: var(--primary-navy);
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}
        
        .upload-button:hover {{
            background: #B7791F;
            transform: translateY(-2px);
        }}
        
        .analysis-results {{
            display: none;
            margin-top: 20px;
            padding: 20px;
            background: rgba(56, 161, 105, 0.1);
            border-radius: 10px;
            border-left: 4px solid var(--success);
        }}
        
        .loading-spinner {{
            display: none;
            text-align: center;
            padding: 20px;
        }}
        
        .spinner {{
            width: 40px;
            height: 40px;
            border: 4px solid var(--accent-silver);
            border-top: 4px solid var(--secondary-gold);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }}
        
        @keyframes spin {{
            0% {{ transform: rotate(0deg); }}
            100% {{ transform: rotate(360deg); }}
        }}
        
        .result-item {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid rgba(26, 54, 93, 0.1);
        }}
        
        .result-item:last-child {{
            border-bottom: none;
        }}
        
        .result-label {{
            font-weight: 600;
            color: var(--primary-navy);
        }}
        
        .result-value {{
            color: var(--secondary-gold);
            font-weight: 700;
        }}
        
        .action-buttons {{
            display: flex;
            gap: 15px;
            margin-top: 20px;
            justify-content: center;
        }}
        
        .btn {{
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}
        
        .btn-primary {{
            background: var(--primary-navy);
            color: var(--white);
        }}
        
        .btn-primary:hover {{
            background: #2D3748;
            transform: translateY(-2px);
        }}
        
        .btn-secondary {{
            background: var(--accent-silver);
            color: var(--primary-navy);
        }}
        
        .btn-secondary:hover {{
            background: #9CA3AF;
            transform: translateY(-2px);
        }}
        
        .error-message {{
            display: none;
            padding: 15px;
            background: rgba(229, 62, 62, 0.1);
            border: 1px solid var(--error);
            border-radius: 8px;
            color: var(--error);
            margin-top: 15px;
        }}
    </style>
</head>
<body>
    <div class="widget-container">
        <div class="widget-header">
            <h2>🤖 AI Window Estimator</h2>
            <p>Upload a photo of your window for instant AI analysis and pricing</p>
        </div>
        
        <div class="upload-area" id="uploadArea">
            <div class="upload-icon"></div>
            <h3>Drop your window photo here</h3>
            <p>or click to browse files</p>
            <button class="upload-button" onclick="document.getElementById('fileInput').click()">
                Choose File
            </button>
            <input type="file" id="fileInput" class="file-input" accept="image/*">
        </div>
        
        <div class="loading-spinner" id="loadingSpinner">
            <div class="spinner"></div>
            <p>Analyzing your window with AI...</p>
        </div>
        
        <div class="analysis-results" id="analysisResults">
            <h3>✅ Analysis Complete</h3>
            <div class="result-item">
                <span class="result-label">Window Type:</span>
                <span class="result-value" id="windowType">-</span>
            </div>
            <div class="result-item">
                <span class="result-label">Dimensions:</span>
                <span class="result-value" id="dimensions">-</span>
            </div>
            <div class="result-item">
                <span class="result-label">Condition:</span>
                <span class="result-value" id="condition">-</span>
            </div>
            <div class="result-item">
                <span class="result-label">Estimated Cost:</span>
                <span class="result-value" id="estimatedCost">-</span>
            </div>
            
            <div class="action-buttons">
                <button class="btn btn-primary" onclick="requestQuote()">
                    Get Detailed Quote
                </button>
                <button class="btn btn-secondary" onclick="analyzeAnother()">
                    Analyze Another
                </button>
            </div>
        </div>
        
        <div class="error-message" id="errorMessage">
            <strong>Error:</strong> <span id="errorText"></span>
        </div>
    </div>

    <script>
        // Widget Configuration
        const BACKEND_URL = '{self.widget_config["backend_url"]}';
        const WIX_SITE_ID = '{self.widget_config["wix_site_id"]}';
        
        // DOM Elements
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');
        const loadingSpinner = document.getElementById('loadingSpinner');
        const analysisResults = document.getElementById('analysisResults');
        const errorMessage = document.getElementById('errorMessage');
        
        // Event Listeners
        uploadArea.addEventListener('click', () => fileInput.click());
        uploadArea.addEventListener('dragover', handleDragOver);
        uploadArea.addEventListener('drop', handleDrop);
        uploadArea.addEventListener('dragleave', handleDragLeave);
        fileInput.addEventListener('change', handleFileSelect);
        
        function handleDragOver(e) {{
            e.preventDefault();
            uploadArea.classList.add('dragover');
        }}
        
        function handleDragLeave(e) {{
            e.preventDefault();
            uploadArea.classList.remove('dragover');
        }}
        
        function handleDrop(e) {{
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {{
                analyzeImage(files[0]);
            }}
        }}
        
        function handleFileSelect(e) {{
            const file = e.target.files[0];
            if (file) {{
                analyzeImage(file);
            }}
        }}
        
        async function analyzeImage(file) {{
            try {{
                // Show loading state
                hideAllSections();
                loadingSpinner.style.display = 'block';
                
                // Prepare form data
                const formData = new FormData();
                formData.append('image', file);
                formData.append('site_id', WIX_SITE_ID);
                
                // Send to AI analysis endpoint
                const response = await fetch(`${{BACKEND_URL}}/api/ai-analysis`, {{
                    method: 'POST',
                    body: formData
                }});
                
                if (!response.ok) {{
                    throw new Error(`Analysis failed: ${{response.statusText}}`);
                }}
                
                const result = await response.json();
                
                // Display results
                displayResults(result);
                
                // Send data to Wix (if parent window exists)
                if (window.parent && window.parent.postMessage) {{
                    window.parent.postMessage({{
                        type: 'ai_analysis_complete',
                        data: result
                    }}, '*');
                }}
                
            }} catch (error) {{
                console.error('Analysis error:', error);
                showError(error.message);
            }}
        }}
        
        function displayResults(result) {{
            hideAllSections();
            
            // Update result values
            document.getElementById('windowType').textContent = result.window_type || 'Unknown';
            document.getElementById('dimensions').textContent = 
                `${{result.width || 'N/A'}} x ${{result.height || 'N/A'}}`;
            document.getElementById('condition').textContent = result.condition || 'Good';
            document.getElementById('estimatedCost').textContent = 
                `$${{result.estimated_cost || '0'}}`;
            
            analysisResults.style.display = 'block';
        }}
        
        function requestQuote() {{
            // Send quote request to parent Wix page
            if (window.parent && window.parent.postMessage) {{
                window.parent.postMessage({{
                    type: 'request_quote',
                    data: {{
                        source: 'ai_estimator',
                        window_type: document.getElementById('windowType').textContent,
                        dimensions: document.getElementById('dimensions').textContent,
                        estimated_cost: document.getElementById('estimatedCost').textContent
                    }}
                }}, '*');
            }}
        }}
        
        function analyzeAnother() {{
            hideAllSections();
            uploadArea.style.display = 'block';
            fileInput.value = '';
        }}
        
        function showError(message) {{
            hideAllSections();
            document.getElementById('errorText').textContent = message;
            errorMessage.style.display = 'block';
        }}
        
        function hideAllSections() {{
            uploadArea.style.display = 'none';
            loadingSpinner.style.display = 'none';
            analysisResults.style.display = 'none';
            errorMessage.style.display = 'none';
        }}
        
        // Initialize widget
        document.addEventListener('DOMContentLoaded', function() {{
            console.log('GFE AI Window Estimator Widget loaded');
            uploadArea.style.display = 'block';
        }});
    </script>
</body>
</html>'''
        
        widget_path = os.path.join(self.widgets_dir, "interactive-components", "ai-window-estimator-widget.html")
        with open(widget_path, 'w', encoding='utf-8') as f:
            f.write(widget_html)
        
        print(f"  ✅ AI Window Estimator Widget created: {widget_path}")
        return widget_path

    def create_window_products_widget(self):
        """Create enhanced Window Products browser widget"""
        print("\n🪟 Creating Window Products Widget...")
        
        widget_html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GFE Window Products Widget</title>
    <style>
        :root {{
            --primary-navy: #1A365D;
            --secondary-gold: #D4AF37;
            --accent-silver: #C0C0C0;
            --white: #FFFFFF;
            --light-gray: #F7FAFC;
        }}
        
        .widget-container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: var(--light-gray);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }}
        
        .widget-header {{
            text-align: center;
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, var(--primary-navy) 0%, #2D3748 100%);
            border-radius: 15px;
            color: var(--white);
        }}
        
        .filters-section {{
            background: var(--white);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 16px rgba(26, 54, 93, 0.1);
        }}
        
        .filter-row {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }}
        
        .filter-group {{
            display: flex;
            flex-direction: column;
        }}
        
        .filter-label {{
            font-weight: 600;
            color: var(--primary-navy);
            margin-bottom: 5px;
        }}
        
        .filter-select {{
            padding: 10px;
            border: 2px solid var(--accent-silver);
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }}
        
        .filter-select:focus {{
            outline: none;
            border-color: var(--secondary-gold);
        }}
        
        .products-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }}
        
        .product-card {{
            background: var(--white);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 8px 32px rgba(26, 54, 93, 0.1);
            transition: all 0.3s ease;
            cursor: pointer;
        }}
        
        .product-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(26, 54, 93, 0.2);
        }}
        
        .product-image {{
            width: 100%;
            height: 200px;
            background: var(--light-gray);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }}
        
        .product-image img {{
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }}
        
        .brand-logo {{
            position: absolute;
            top: 10px;
            right: 10px;
            width: 40px;
            height: 40px;
            background: var(--white);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }}
        
        .brand-logo img {{
            width: 30px;
            height: 30px;
            object-fit: contain;
        }}
        
        .product-info {{
            padding: 20px;
        }}
        
        .product-title {{
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--primary-navy);
            margin-bottom: 10px;
        }}
        
        .product-details {{
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 15px;
        }}
        
        .detail-item {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
        }}
        
        .detail-label {{
            color: var(--primary-navy);
            font-weight: 500;
        }}
        
        .detail-value {{
            color: var(--secondary-gold);
            font-weight: 600;
        }}
        
        .product-actions {{
            display: flex;
            gap: 10px;
        }}
        
        .btn {{
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }}
        
        .btn-primary {{
            background: var(--primary-navy);
            color: var(--white);
        }}
        
        .btn-primary:hover {{
            background: #2D3748;
        }}
        
        .btn-secondary {{
            background: var(--secondary-gold);
            color: var(--primary-navy);
        }}
        
        .btn-secondary:hover {{
            background: #B7791F;
        }}
        
        .loading-state {{
            text-align: center;
            padding: 40px;
            color: var(--primary-navy);
        }}
        
        .no-results {{
            text-align: center;
            padding: 40px;
            color: var(--primary-navy);
        }}
    </style>
</head>
<body>
    <div class="widget-container">
        <div class="widget-header">
            <h2>🪟 Premium Window Products</h2>
            <p>Explore our selection of high-quality windows from top manufacturers</p>
        </div>
        
        <div class="filters-section">
            <div class="filter-row">
                <div class="filter-group">
                    <label class="filter-label">Brand</label>
                    <select class="filter-select" id="brandFilter">
                        <option value="">All Brands</option>
                        <option value="Andersen">Andersen</option>
                        <option value="Marvin">Marvin</option>
                        <option value="Pella">Pella</option>
                        <option value="Provia">Provia</option>
                        <option value="Thermo-Tech">Thermo-Tech</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Window Type</label>
                    <select class="filter-select" id="typeFilter">
                        <option value="">All Types</option>
                        <option value="Double-Hung">Double-Hung</option>
                        <option value="Single-Hung">Single-Hung</option>
                        <option value="Casement">Casement</option>
                        <option value="Sliding">Sliding</option>
                        <option value="Bay">Bay</option>
                        <option value="Picture">Picture</option>
                        <option value="Awning">Awning</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Material</label>
                    <select class="filter-select" id="materialFilter">
                        <option value="">All Materials</option>
                        <option value="Vinyl">Vinyl</option>
                        <option value="Wood">Wood</option>
                        <option value="Fiberglass">Fiberglass</option>
                        <option value="Aluminum">Aluminum</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label">Price Range</label>
                    <select class="filter-select" id="priceFilter">
                        <option value="">All Prices</option>
                        <option value="0-500">$0 - $500</option>
                        <option value="500-1000">$500 - $1,000</option>
                        <option value="1000-2000">$1,000 - $2,000</option>
                        <option value="2000+">$2,000+</option>
                    </select>
                </div>
            </div>
        </div>
        
        <div id="loadingState" class="loading-state">
            <p>Loading window products...</p>
        </div>
        
        <div id="productsGrid" class="products-grid" style="display: none;">
            <!-- Products will be loaded here -->
        </div>
        
        <div id="noResults" class="no-results" style="display: none;">
            <p>No products found matching your criteria.</p>
        </div>
    </div>

    <script>
        // Widget Configuration
        const BACKEND_URL = '{self.widget_config["backend_url"]}';
        const WIX_SITE_ID = '{self.widget_config["wix_site_id"]}';
        
        // Brand logos mapping
        const BRAND_LOGOS = {json.dumps(self.widget_config["brand_logos"])};
        
        // Window type images mapping
        const WINDOW_IMAGES = {json.dumps(self.widget_config["window_types"])};
        
        // Sample products data (in production, this would come from API)
        const SAMPLE_PRODUCTS = [
            {{
                id: 1,
                brand: "Andersen",
                series: "400 Series",
                windowType: "Double-Hung",
                material: "Wood",
                description: "Premium wood double-hung window with superior energy efficiency",
                energyRating: "Energy Star",
                warranty: "20 Years",
                basePrice: 850,
                features: ["Low-E Glass", "Argon Fill", "Weather Stripping"]
            }},
            {{
                id: 2,
                brand: "Marvin",
                series: "Essential",
                windowType: "Casement",
                material: "Fiberglass",
                description: "Durable fiberglass casement window with excellent insulation",
                energyRating: "Energy Star",
                warranty: "10 Years",
                basePrice: 720,
                features: ["Triple Pane", "Low-E Coating", "Foam Insulation"]
            }},
            {{
                id: 3,
                brand: "Pella",
                series: "Impervia",
                windowType: "Sliding",
                material: "Fiberglass",
                description: "Low-maintenance sliding window with superior durability",
                energyRating: "Energy Star Most Efficient",
                warranty: "Limited Lifetime",
                basePrice: 650,
                features: ["Easy Clean", "Security Lock", "Weather Seal"]
            }}
        ];
        
        let currentProducts = [];
        
        // DOM Elements
        const loadingState = document.getElementById('loadingState');
        const productsGrid = document.getElementById('productsGrid');
        const noResults = document.getElementById('noResults');
        const brandFilter = document.getElementById('brandFilter');
        const typeFilter = document.getElementById('typeFilter');
        const materialFilter = document.getElementById('materialFilter');
        const priceFilter = document.getElementById('priceFilter');
        
        // Event Listeners
        brandFilter.addEventListener('change', filterProducts);
        typeFilter.addEventListener('change', filterProducts);
        materialFilter.addEventListener('change', filterProducts);
        priceFilter.addEventListener('change', filterProducts);
        
        async function loadProducts() {{
            try {{
                // In production, fetch from API
                // const response = await fetch(`${{BACKEND_URL}}/api/window-products`);
                // const products = await response.json();
                
                // For now, use sample data
                currentProducts = SAMPLE_PRODUCTS;
                displayProducts(currentProducts);
                
            }} catch (error) {{
                console.error('Error loading products:', error);
                showNoResults();
            }}
        }}
        
        function displayProducts(products) {{
            loadingState.style.display = 'none';
            noResults.style.display = 'none';
            
            if (products.length === 0) {{
                showNoResults();
                return;
            }}
            
            productsGrid.innerHTML = products.map(product => createProductCard(product)).join('');
            productsGrid.style.display = 'grid';
        }}
        
        function createProductCard(product) {{
            const brandLogo = BRAND_LOGOS[product.brand.toLowerCase()] || '';
            const windowImage = WINDOW_IMAGES[product.windowType.toLowerCase().replace('-', '_')] || '';
            
            return `
                <div class="product-card" onclick="selectProduct(${{product.id}})">
                    <div class="product-image">
                        <img src="${{windowImage}}" alt="${{product.windowType}} Window" />
                        <div class="brand-logo">
                            <img src="${{brandLogo}}" alt="${{product.brand}} Logo" />
                        </div>
                    </div>
                    <div class="product-info">
                        <div class="product-title">${{product.brand}} ${{product.series}}</div>
                        <div class="product-details">
                            <div class="detail-item">
                                <span class="detail-label">Type:</span>
                                <span class="detail-value">${{product.windowType}}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Material:</span>
                                <span class="detail-value">${{product.material}}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Energy Rating:</span>
                                <span class="detail-value">${{product.energyRating}}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Starting Price:</span>
                                <span class="detail-value">$${{product.basePrice}}</span>
                            </div>
                        </div>
                        <div class="product-actions">
                            <button class="btn btn-primary" onclick="event.stopPropagation(); getQuote(${{product.id}})">
                                Get Quote
                            </button>
                            <button class="btn btn-secondary" onclick="event.stopPropagation(); viewDetails(${{product.id}})">
                                Details
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }}
        
        function filterProducts() {{
            const brand = brandFilter.value;
            const type = typeFilter.value;
            const material = materialFilter.value;
            const priceRange = priceFilter.value;
            
            let filtered = currentProducts.filter(product => {{
                if (brand && product.brand !== brand) return false;
                if (type && product.windowType !== type) return false;
                if (material && product.material !== material) return false;
                
                if (priceRange) {{
                    const [min, max] = priceRange.split('-').map(p => parseInt(p) || Infinity);
                    if (product.basePrice < min || (max !== Infinity && product.basePrice > max)) return false;
                }}
                
                return true;
            }});
            
            displayProducts(filtered);
        }}
        
        function selectProduct(productId) {{
            const product = currentProducts.find(p => p.id === productId);
            if (product && window.parent && window.parent.postMessage) {{
                window.parent.postMessage({{
                    type: 'product_selected',
                    data: product
                }}, '*');
            }}
        }}
        
        function getQuote(productId) {{
            const product = currentProducts.find(p => p.id === productId);
            if (product && window.parent && window.parent.postMessage) {{
                window.parent.postMessage({{
                    type: 'request_quote',
                    data: {{
                        source: 'product_browser',
                        product: product
                    }}
                }}, '*');
            }}
        }}
        
        function viewDetails(productId) {{
            const product = currentProducts.find(p => p.id === productId);
            if (product && window.parent && window.parent.postMessage) {{
                window.parent.postMessage({{
                    type: 'view_product_details',
                    data: product
                }}, '*');
            }}
        }}
        
        function showNoResults() {{
            loadingState.style.display = 'none';
            productsGrid.style.display = 'none';
            noResults.style.display = 'block';
        }}
        
        // Initialize widget
        document.addEventListener('DOMContentLoaded', function() {{
            console.log('GFE Window Products Widget loaded');
            loadProducts();
        }});
    </script>
</body>
</html>'''
        
        widget_path = os.path.join(self.widgets_dir, "interactive-components", "window-products-widget.html")
        with open(widget_path, 'w', encoding='utf-8') as f:
            f.write(widget_html)
        
        print(f"  ✅ Window Products Widget created: {widget_path}")
        return widget_path

    def create_velo_integration_controller(self):
        """Create Velo integration controller for widgets"""
        print("\n🔗 Creating Velo Integration Controller...")
        
        velo_controller = '''// Good Faith Exteriors - Velo Widget Integration Controller
// Handles communication between HTML widgets and Wix Velo

import wixData from 'wix-data';
import wixLocation from 'wix-location';

// Configuration
const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";
const WIDGET_CONFIG = {
    ai_estimator: {
        elementId: '#aiEstimatorWidget',
        collection: 'GFE_Leads'
    },
    window_products: {
        elementId: '#windowProductsWidget',
        collection: 'GFE_WindowProducts'
    },
    quote_builder: {
        elementId: '#quoteBuilderWidget',
        collection: 'GFE_Quotes'
    }
};

// Widget Communication Handler
export function initializeWidgetCommunication() {
    console.log('Initializing GFE Widget Communication...');
    
    // Listen for messages from widgets
    if (typeof window !== 'undefined') {
        window.addEventListener('message', handleWidgetMessage);
    }
    
    // Initialize each widget
    Object.keys(WIDGET_CONFIG).forEach(widgetType => {
        initializeWidget(widgetType);
    });
}

function handleWidgetMessage(event) {
    console.log('Widget message received:', event.data);
    
    const { type, data } = event.data;
    
    switch (type) {
        case 'ai_analysis_complete':
            handleAIAnalysisComplete(data);
            break;
            
        case 'product_selected':
            handleProductSelected(data);
            break;
            
        case 'request_quote':
            handleQuoteRequest(data);
            break;
            
        case 'view_product_details':
            handleViewProductDetails(data);
            break;
            
        default:
            console.log('Unknown widget message type:', type);
    }
}

async function handleAIAnalysisComplete(analysisData) {
    console.log('AI Analysis completed:', analysisData);
    
    try {
        // Save analysis result to Wix Data
        const leadData = {
            leadId: generateLeadId(),
            source: 'ai_estimator',
            projectType: 'window_replacement',
            windowType: analysisData.window_type,
            estimatedCost: analysisData.estimated_cost,
            analysisData: JSON.stringify(analysisData),
            createdDate: new Date(),
            status: 'new'
        };
        
        await wixData.save('GFE_Leads', leadData);
        
        // Show success message
        showNotification('Analysis saved! Would you like to get a detailed quote?', 'success');
        
        // Optionally redirect to quote page
        if (analysisData.estimated_cost > 0) {
            setTimeout(() => {
                wixLocation.to('/quote-builder?analysis=' + encodeURIComponent(JSON.stringify(analysisData)));
            }, 2000);
        }
        
    } catch (error) {
        console.error('Error saving analysis:', error);
        showNotification('Error saving analysis. Please try again.', 'error');
    }
}

async function handleProductSelected(productData) {
    console.log('Product selected:', productData);
    
    try {
        // Update product view count
        await updateProductViews(productData.id);
        
        // Show product details in lightbox or modal
        showProductDetails(productData);
        
    } catch (error) {
        console.error('Error handling product selection:', error);
    }
}

async function handleQuoteRequest(requestData) {
    console.log('Quote requested:', requestData);
    
    try {
        // Create quote request in Wix Data
        const quoteData = {
            quoteId: generateQuoteId(),
            source: requestData.source,
            requestData: JSON.stringify(requestData),
            status: 'pending',
            createdDate: new Date()
        };
        
        if (requestData.product) {
            quoteData.productId = requestData.product.id;
            quoteData.productBrand = requestData.product.brand;
            quoteData.productType = requestData.product.windowType;
            quoteData.estimatedPrice = requestData.product.basePrice;
        }
        
        await wixData.save('GFE_Quotes', quoteData);
        
        // Redirect to quote form
        wixLocation.to('/quote-form?request=' + encodeURIComponent(JSON.stringify(requestData)));
        
    } catch (error) {
        console.error('Error creating quote request:', error);
        showNotification('Error creating quote request. Please try again.', 'error');
    }
}

function handleViewProductDetails(productData) {
    console.log('View product details:', productData);
    
    // Open product details page or modal
    wixLocation.to('/product-details?id=' + productData.id);
}

function initializeWidget(widgetType) {
    const config = WIDGET_CONFIG[widgetType];
    const widget = $w(config.elementId);
    
    if (widget) {
        console.log(`Initializing ${widgetType} widget`);
        
        // Configure widget settings
        widget.onMessage((event) => {
            handleWidgetMessage(event);
        });
        
        // Send initial configuration to widget
        widget.postMessage({
            type: 'configure',
            config: {
                backendUrl: BACKEND_URL,
                widgetType: widgetType,
                collection: config.collection
            }
        });
    }
}

async function updateProductViews(productId) {
    try {
        const product = await wixData.get('GFE_WindowProducts', productId);
        if (product) {
            const viewCount = (product.viewCount || 0) + 1;
            await wixData.update('GFE_WindowProducts', {
                _id: productId,
                viewCount: viewCount,
                lastViewed: new Date()
            });
        }
    } catch (error) {
        console.error('Error updating product views:', error);
    }
}

function showProductDetails(productData) {
    // Implementation depends on your site structure
    // Could open a lightbox, modal, or navigate to details page
    console.log('Showing product details for:', productData);
}

function showNotification(message, type = 'info') {
    // Implementation depends on your notification system
    console.log(`${type.toUpperCase()}: ${message}`);
    
    // Example: Show in a Wix element
    if ($w('#notificationBar')) {
        $w('#notificationBar').text = message;
        $w('#notificationBar').show();
        
        setTimeout(() => {
            $w('#notificationBar').hide();
        }, 5000);
    }
}

function generateLeadId() {
    return 'lead_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function generateQuoteId() {
    return 'quote_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// Export functions for use in page code
export {
    handleAIAnalysisComplete,
    handleProductSelected,
    handleQuoteRequest,
    handleViewProductDetails,
    showNotification
};'''
        
        controller_path = os.path.join(self.widgets_dir, "velo-integrations", "widget-integration-controller.js")
        with open(controller_path, 'w', encoding='utf-8') as f:
            f.write(velo_controller)
        
        print(f"  ✅ Velo Integration Controller created: {controller_path}")
        return controller_path

    def create_widget_configurations(self):
        """Create widget configuration files"""
        print("\n⚙️  Creating Widget Configuration Files...")
        
        config_dir = os.path.join(self.widgets_dir, "configurations")
        
        # Main widget configuration
        widget_config = {
            "widgets": {
                "ai_window_estimator": {
                    "name": "AI Window Estimator",
                    "description": "AI-powered window analysis and estimation",
                    "file": "ai-window-estimator-widget.html",
                    "wix_element_id": "#aiEstimatorWidget",
                    "collection": "GFE_Leads",
                    "api_endpoints": [
                        f"{self.widget_config['backend_url']}/api/ai-analysis"
                    ],
                    "features": [
                        "image_upload",
                        "ai_analysis", 
                        "cost_estimation",
                        "quote_generation"
                    ]
                },
                "window_products": {
                    "name": "Window Products Browser",
                    "description": "Interactive window products catalog",
                    "file": "window-products-widget.html",
                    "wix_element_id": "#windowProductsWidget",
                    "collection": "GFE_WindowProducts",
                    "api_endpoints": [
                        f"{self.widget_config['backend_url']}/api/window-products"
                    ],
                    "features": [
                        "product_filtering",
                        "brand_selection",
                        "price_comparison",
                        "quote_request"
                    ]
                }
            },
            "global_config": {
                "backend_url": self.widget_config["backend_url"],
                "wix_site_id": self.widget_config["wix_site_id"],
                "theme": {
                    "primary_color": "#1A365D",
                    "secondary_color": "#D4AF37",
                    "accent_color": "#C0C0C0"
                },
                "assets": self.widget_config["image_assets"]
            }
        }
        
        with open(os.path.join(config_dir, "widgets_config.json"), 'w') as f:
            json.dump(widget_config, f, indent=2)
        print(f"  📄 Created: widgets_config.json")
        
        # Deployment instructions for widgets
        deployment_instructions = '''# Widget Deployment Instructions

## Overview
This directory contains interactive widgets for the Good Faith Exteriors website.

## Widget Components

### 1. AI Window Estimator Widget
- **File:** `interactive-components/ai-window-estimator-widget.html`
- **Purpose:** AI-powered window analysis and cost estimation
- **Wix Element ID:** `#aiEstimatorWidget`
- **Collection:** `GFE_Leads`

### 2. Window Products Widget
- **File:** `interactive-components/window-products-widget.html`
- **Purpose:** Interactive product catalog and browser
- **Wix Element ID:** `#windowProductsWidget`
- **Collection:** `GFE_WindowProducts`

## Deployment Steps

### 1. Upload Widget HTML Files
1. Copy widget HTML files to your Wix site
2. Add HTML components to appropriate pages
3. Assign the correct element IDs

### 2. Deploy Velo Integration
1. Copy `velo-integrations/widget-integration-controller.js` to your Velo backend
2. Import and initialize in your page code:
   ```javascript
   import { initializeWidgetCommunication } from 'backend/widget-integration-controller';
   
   $w.onReady(function () {
       initializeWidgetCommunication();
   });
   ```

### 3. Configure Widget Communication
1. Ensure HTML components have message event handlers enabled
2. Set up proper element IDs in Wix Editor
3. Test widget-to-Velo communication

### 4. Test Widget Functionality
1. Test AI analysis functionality
2. Test product browsing and filtering
3. Test quote request generation
4. Verify data saving to collections

## Widget Features

### AI Window Estimator
- ✅ Drag & drop image upload
- ✅ AI-powered window analysis
- ✅ Cost estimation
- ✅ Quote request generation
- ✅ Wix Data integration

### Window Products Browser
- ✅ Product filtering by brand, type, material
- ✅ Price range filtering
- ✅ Interactive product cards
- ✅ Quote request functionality
- ✅ Product detail viewing

## Configuration

All widgets are configured via the `configurations/widgets_config.json` file.
Update this file to modify:
- Backend API endpoints
- Wix site configuration
- Theme colors and styling
- Asset URLs

## Support

For technical support with widget deployment:
1. Check browser console for error messages
2. Verify API endpoint connectivity
3. Ensure Wix Data collections are properly configured
4. Test widget communication with parent page
'''
        
        with open(os.path.join(config_dir, "deployment_instructions.md"), 'w') as f:
            f.write(deployment_instructions)
        print(f"  📄 Created: deployment_instructions.md")

    def run_widget_configuration(self):
        """Run the complete widget configuration process"""
        print("\n🚀 Starting Widget Configuration Process...")
        print("=" * 60)
        
        # Create directory structure
        self.create_widgets_directory()
        
        # Create widgets
        ai_widget = self.create_ai_window_estimator_widget()
        products_widget = self.create_window_products_widget()
        
        # Create integrations
        velo_controller = self.create_velo_integration_controller()
        
        # Create configurations
        self.create_widget_configurations()
        
        print("\n" + "=" * 60)
        print("🎉 Widget Configuration Completed!")
        print(f"📁 Widgets Directory: {self.widgets_dir}")
        print(f"🤖 AI Estimator Widget: {ai_widget}")
        print(f"🪟 Products Widget: {products_widget}")
        print(f"🔗 Velo Controller: {velo_controller}")
        
        return {
            "widgets_dir": self.widgets_dir,
            "ai_widget": ai_widget,
            "products_widget": products_widget,
            "velo_controller": velo_controller,
            "config": self.widget_config
        }

def main():
    """Main widget configuration function"""
    try:
        configurator = WidgetConfiguration()
        results = configurator.run_widget_configuration()
        
        # Save widget configuration results
        with open('/home/ubuntu/widget_config_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n📋 Widget configuration results saved to widget_config_results.json")
        return results
        
    except Exception as e:
        print(f"❌ Widget configuration failed: {str(e)}")
        return {"status": "failed", "error": str(e)}

if __name__ == "__main__":
    main()

