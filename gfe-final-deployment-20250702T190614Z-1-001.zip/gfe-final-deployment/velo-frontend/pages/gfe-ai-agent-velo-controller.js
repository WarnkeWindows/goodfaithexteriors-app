/**
 * Good Faith Exteriors - AI Agent Velo Page Controller
 * Handles communication between AI Agent iframe and Wix backend systems
 * Integrates with Google Cloud backend at https://w5hni7cogw3e.manus.space
 */

import wixData from 'wix-data';
import { fetch } from 'wix-fetch';
import wixLocation from 'wix-location';

// Configuration
const GFE_CONFIG = {
    backendUrl: 'https://w5hni7cogw3e.manus.space',
    apiEndpoints: {
        chat: '/api/ai/chat',
        estimate: '/api/quotes/estimate',
        products: '/api/products/windows',
        schedule: '/api/appointments/schedule',
        leads: '/api/crm/leads',
        health: '/api/health'
    },
    collections: {
        conversations: 'AIConversations',
        leads: 'CRMLeads',
        quotes: 'Quotes',
        appointments: 'Appointments',
        analytics: 'Analytics'
    }
};

let currentSession = null;
let conversationLog = [];

// Page initialization
$w.onReady(function () {
    console.log('GFE AI Agent Page Controller initialized');
    
    // Initialize AI Agent iframe
    initializeAIAgent();
    
    // Set up global message listener
    setupMessageListener();
    
    // Verify backend connectivity
    verifyBackendConnection();
});

// Initialize AI Agent iframe
function initializeAIAgent() {
    const aiIframe = $w('#aiAgentIframe');
    
    if (aiIframe) {
        aiIframe.onLoad(() => {
            console.log('AI Agent iframe loaded successfully');
            
            // Send initialization message to iframe
            sendToIframe({
                type: 'system_message',
                message: 'Connected to Good Faith Exteriors backend system'
            });
        });
    } else {
        console.error('AI Agent iframe not found. Make sure element ID is "aiAgentIframe"');
    }
}

// Set up global message listener for iframe communication
function setupMessageListener() {
    // Listen for messages from AI Agent iframe
    window.addEventListener('message', async function(event) {
        // Security check - only accept messages from our iframe
        if (!event.data || typeof event.data !== 'object') {
            return;
        }
        
        const { type, message, sessionId, timestamp, data } = event.data;
        
        console.log('Received message from AI Agent:', { type, sessionId });
        
        try {
            switch (type) {
                case 'ai_agent_initialized':
                    await handleAgentInitialization(sessionId, timestamp);
                    break;
                    
                case 'ai_chat_message':
                    await handleChatMessage(message, sessionId, timestamp, data);
                    break;
                    
                case 'ai_estimate_request':
                    await handleEstimateRequest(data, sessionId);
                    break;
                    
                case 'ai_schedule_request':
                    await handleScheduleRequest(data, sessionId);
                    break;
                    
                case 'ai_lead_capture':
                    await handleLeadCapture(data, sessionId);
                    break;
                    
                case 'ai_agent_focus':
                    await handleAgentFocus(sessionId, timestamp);
                    break;
                    
                default:
                    console.log('Unknown message type from AI Agent:', type);
            }
        } catch (error) {
            console.error('Error handling AI Agent message:', error);
            
            // Send error message back to iframe
            sendToIframe({
                type: 'error',
                message: 'Sorry, there was an error processing your request. Please try again.'
            });
        }
    });
}

// Handle AI Agent initialization
async function handleAgentInitialization(sessionId, timestamp) {
    try {
        currentSession = {
            id: sessionId,
            startTime: new Date(timestamp),
            messageCount: 0,
            lastActivity: new Date()
        };
        
        // Log session start
        await logAnalytics('ai_agent_session_start', {
            sessionId: sessionId,
            timestamp: timestamp,
            userAgent: navigator.userAgent,
            referrer: document.referrer
        });
        
        console.log('AI Agent session initialized:', sessionId);
        
    } catch (error) {
        console.error('Error initializing AI Agent session:', error);
    }
}

// Handle chat messages from AI Agent
async function handleChatMessage(message, sessionId, timestamp, additionalData) {
    try {
        // Update session activity
        if (currentSession && currentSession.id === sessionId) {
            currentSession.lastActivity = new Date();
            currentSession.messageCount++;
        }
        
        // Process message with backend AI service
        const aiResponse = await processWithBackendAI(message, sessionId, additionalData);
        
        if (aiResponse) {
            // Send AI response back to iframe
            sendToIframe({
                type: 'ai_response',
                message: aiResponse.message,
                confidence: aiResponse.confidence,
                suggestions: aiResponse.suggestions,
                responseType: aiResponse.type
            });
            
            // Log conversation
            await logConversation(message, aiResponse.message, sessionId, timestamp);
            
            // Handle special response types
            if (aiResponse.type === 'estimate_trigger') {
                await handleEstimateFromChat(aiResponse.data, sessionId);
            } else if (aiResponse.type === 'schedule_trigger') {
                await handleScheduleFromChat(aiResponse.data, sessionId);
            } else if (aiResponse.type === 'lead_capture_trigger') {
                await handleLeadFromChat(aiResponse.data, sessionId);
            }
        }
        
    } catch (error) {
        console.error('Error processing chat message:', error);
        
        // Send fallback response
        sendToIframe({
            type: 'ai_response',
            message: 'I apologize, but I\'m having trouble processing your request right now. Please try again or contact our support team at (555) 123-4567.',
            error: true
        });
    }
}

// Process message with backend AI service
async function processWithBackendAI(message, sessionId, additionalData) {
    try {
        const requestData = {
            message: message,
            sessionId: sessionId,
            context: {
                source: 'wix_velo_ai_agent',
                conversationHistory: additionalData?.conversationHistory || [],
                timestamp: new Date().toISOString(),
                userContext: await getUserContext()
            }
        };
        
        const response = await fetch(`${GFE_CONFIG.backendUrl}${GFE_CONFIG.apiEndpoints.chat}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': sessionId,
                'X-Source': 'wix-velo'
            },
            body: JSON.stringify(requestData)
        });
        
        if (response.ok) {
            const data = await response.json();
            return data;
        } else {
            throw new Error(`Backend AI service error: ${response.status}`);
        }
        
    } catch (error) {
        console.error('Backend AI service error:', error);
        
        // Return fallback response
        return generateFallbackResponse(message);
    }
}

// Generate fallback response when backend is unavailable
function generateFallbackResponse(message) {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('estimate') || lowerMessage.includes('quote')) {
        return {
            message: "I'd be happy to help you get a window estimate! Let me connect you with our estimation system. What type of windows are you interested in?",
            type: 'estimate_trigger',
            confidence: 0.8,
            suggestions: ['Get instant quote', 'Schedule consultation', 'View window types']
        };
    }
    
    if (lowerMessage.includes('schedule') || lowerMessage.includes('appointment')) {
        return {
            message: "I can help you schedule a free consultation with our window experts. What days work best for you?",
            type: 'schedule_trigger',
            confidence: 0.8,
            suggestions: ['This week', 'Next week', 'Weekends preferred']
        };
    }
    
    return {
        message: "Thank you for your message! I'm here to help with window estimates, product information, and scheduling. How can I assist you today?",
        type: 'general',
        confidence: 0.7,
        suggestions: ['Get estimate', 'View products', 'Schedule visit', 'Contact support']
    };
}

// Handle estimate requests
async function handleEstimateRequest(data, sessionId) {
    try {
        // Process estimate through backend
        const estimateResponse = await fetch(`${GFE_CONFIG.backendUrl}${GFE_CONFIG.apiEndpoints.estimate}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': sessionId
            },
            body: JSON.stringify(data)
        });
        
        if (estimateResponse.ok) {
            const estimate = await estimateResponse.json();
            
            // Save estimate to Wix collection
            await saveEstimateToWix(estimate, sessionId);
            
            // Send response back to iframe
            sendToIframe({
                type: 'estimate_response',
                data: estimate,
                message: `Estimate generated: $${estimate.total} for ${estimate.quantity} windows`
            });
            
        } else {
            throw new Error('Estimate service unavailable');
        }
        
    } catch (error) {
        console.error('Error processing estimate request:', error);
        
        sendToIframe({
            type: 'error',
            message: 'Sorry, I\'m having trouble generating your estimate. Please try again or contact us directly.'
        });
    }
}

// Handle schedule requests
async function handleScheduleRequest(data, sessionId) {
    try {
        // Process appointment through backend
        const scheduleResponse = await fetch(`${GFE_CONFIG.backendUrl}${GFE_CONFIG.apiEndpoints.schedule}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': sessionId
            },
            body: JSON.stringify(data)
        });
        
        if (scheduleResponse.ok) {
            const appointment = await scheduleResponse.json();
            
            // Save appointment to Wix collection
            await saveAppointmentToWix(appointment, sessionId);
            
            // Send confirmation back to iframe
            sendToIframe({
                type: 'schedule_response',
                data: appointment,
                message: `Appointment scheduled for ${appointment.date} at ${appointment.time}. Reference: ${appointment.id}`
            });
            
        } else {
            throw new Error('Scheduling service unavailable');
        }
        
    } catch (error) {
        console.error('Error processing schedule request:', error);
        
        sendToIframe({
            type: 'error',
            message: 'Sorry, I\'m having trouble scheduling your appointment. Please call us at (555) 123-4567.'
        });
    }
}

// Handle lead capture
async function handleLeadCapture(data, sessionId) {
    try {
        // Create lead in backend
        const leadResponse = await fetch(`${GFE_CONFIG.backendUrl}${GFE_CONFIG.apiEndpoints.leads}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Session-ID': sessionId
            },
            body: JSON.stringify({
                ...data,
                source: 'ai_agent',
                sessionId: sessionId
            })
        });
        
        if (leadResponse.ok) {
            const lead = await leadResponse.json();
            
            // Save lead to Wix collection
            await saveLeadToWix(lead, sessionId);
            
            // Send confirmation back to iframe
            sendToIframe({
                type: 'lead_captured',
                data: lead,
                message: 'Thank you! We\'ve received your information and will contact you soon.'
            });
            
        } else {
            throw new Error('Lead capture service unavailable');
        }
        
    } catch (error) {
        console.error('Error capturing lead:', error);
        
        sendToIframe({
            type: 'error',
            message: 'Sorry, there was an error saving your information. Please try again.'
        });
    }
}

// Save estimate to Wix collection
async function saveEstimateToWix(estimate, sessionId) {
    try {
        await wixData.save(GFE_CONFIG.collections.quotes, {
            estimateId: estimate.id,
            sessionId: sessionId,
            customerInfo: estimate.customerInfo,
            windowDetails: estimate.windowDetails,
            pricing: estimate.pricing,
            total: estimate.total,
            status: 'ai_generated',
            source: 'ai_agent',
            createdDate: new Date(),
            expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
        });
        
        console.log('Estimate saved to Wix:', estimate.id);
        
    } catch (error) {
        console.error('Error saving estimate to Wix:', error);
    }
}

// Save appointment to Wix collection
async function saveAppointmentToWix(appointment, sessionId) {
    try {
        await wixData.save(GFE_CONFIG.collections.appointments, {
            appointmentId: appointment.id,
            sessionId: sessionId,
            customerInfo: appointment.customerInfo,
            scheduledDate: new Date(appointment.date),
            scheduledTime: appointment.time,
            type: appointment.type || 'consultation',
            status: 'scheduled',
            source: 'ai_agent',
            createdDate: new Date(),
            notes: appointment.notes || 'Scheduled via AI Agent'
        });
        
        console.log('Appointment saved to Wix:', appointment.id);
        
    } catch (error) {
        console.error('Error saving appointment to Wix:', error);
    }
}

// Save lead to Wix collection
async function saveLeadToWix(lead, sessionId) {
    try {
        await wixData.save(GFE_CONFIG.collections.leads, {
            leadId: lead.id,
            sessionId: sessionId,
            customerInfo: lead.customerInfo,
            interests: lead.interests,
            source: 'ai_agent',
            status: 'new',
            priority: lead.priority || 'medium',
            createdDate: new Date(),
            lastContact: new Date(),
            notes: lead.notes || 'Generated via AI Agent'
        });
        
        console.log('Lead saved to Wix:', lead.id);
        
    } catch (error) {
        console.error('Error saving lead to Wix:', error);
    }
}

// Log conversation for analytics
async function logConversation(userMessage, aiResponse, sessionId, timestamp) {
    try {
        await wixData.save(GFE_CONFIG.collections.conversations, {
            sessionId: sessionId,
            userMessage: userMessage,
            aiResponse: aiResponse,
            timestamp: new Date(timestamp),
            messageIndex: conversationLog.length,
            source: 'ai_agent',
            processed: true
        });
        
        // Add to local conversation log
        conversationLog.push({
            user: userMessage,
            ai: aiResponse,
            timestamp: timestamp
        });
        
        // Keep only last 50 conversations in memory
        if (conversationLog.length > 50) {
            conversationLog = conversationLog.slice(-50);
        }
        
    } catch (error) {
        console.error('Error logging conversation:', error);
    }
}

// Log analytics events
async function logAnalytics(eventType, data) {
    try {
        await wixData.save(GFE_CONFIG.collections.analytics, {
            eventType: eventType,
            eventData: data,
            timestamp: new Date(),
            source: 'ai_agent_velo',
            sessionId: data.sessionId || 'unknown'
        });
        
    } catch (error) {
        console.error('Error logging analytics:', error);
    }
}

// Get user context for AI processing
async function getUserContext() {
    try {
        return {
            url: wixLocation.url,
            path: wixLocation.path,
            query: wixLocation.query,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            language: navigator.language
        };
    } catch (error) {
        console.error('Error getting user context:', error);
        return {};
    }
}

// Send message to AI Agent iframe
function sendToIframe(data) {
    try {
        const aiIframe = $w('#aiAgentIframe');
        if (aiIframe) {
            aiIframe.contentWindow.postMessage(data, '*');
        }
    } catch (error) {
        console.error('Error sending message to iframe:', error);
    }
}

// Verify backend connection
async function verifyBackendConnection() {
    try {
        const response = await fetch(`${GFE_CONFIG.backendUrl}${GFE_CONFIG.apiEndpoints.health}`, {
            method: 'GET',
            headers: {
                'X-Source': 'wix-velo-health-check'
            }
        });
        
        if (response.ok) {
            const healthData = await response.json();
            console.log('Backend connection verified:', healthData);
            
            // Send status to iframe
            sendToIframe({
                type: 'system_message',
                message: 'Backend systems operational ✅'
            });
            
        } else {
            throw new Error('Backend health check failed');
        }
        
    } catch (error) {
        console.error('Backend connection error:', error);
        
        // Send warning to iframe
        sendToIframe({
            type: 'system_message',
            message: 'Backend connection limited - some features may be unavailable'
        });
    }
}

// Handle agent focus events
async function handleAgentFocus(sessionId, timestamp) {
    try {
        if (currentSession && currentSession.id === sessionId) {
            currentSession.lastActivity = new Date();
            
            // Log focus event
            await logAnalytics('ai_agent_focus', {
                sessionId: sessionId,
                timestamp: timestamp
            });
        }
    } catch (error) {
        console.error('Error handling agent focus:', error);
    }
}

// Cleanup function for page unload
window.addEventListener('beforeunload', function() {
    if (currentSession) {
        // Log session end
        logAnalytics('ai_agent_session_end', {
            sessionId: currentSession.id,
            duration: Date.now() - currentSession.startTime.getTime(),
            messageCount: currentSession.messageCount
        });
    }
});

// Export functions for testing and debugging
export {
    handleChatMessage,
    processWithBackendAI,
    saveEstimateToWix,
    saveAppointmentToWix,
    saveLeadToWix,
    verifyBackendConnection
};

