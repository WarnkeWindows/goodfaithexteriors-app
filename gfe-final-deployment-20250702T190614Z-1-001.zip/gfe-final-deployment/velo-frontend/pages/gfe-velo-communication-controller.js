/**
 * ========================================================================
 * GFE VELO COMMUNICATION CONTROLLER
 * ========================================================================
 * Comprehensive communication system for Good Faith Exteriors iframes
 * Handles all postMessage communication with Wix parent pages
 * Implements strict security validation and event handling
 */

class GFEVeloCommunicationController {
    constructor(componentName, options = {}) {
        this.componentName = componentName;
        this.options = {
            enableLogging: options.enableLogging !== false,
            autoInit: options.autoInit !== false,
            trustedOrigins: options.trustedOrigins || [
                'https://goodfaithexteriors.com',
                'https://www.goodfaithexteriors.com',
                'https://gfe-ai-advisor.netlify.app',
                'https://editor.wix.com',
                'https://www.wix.com',
                'https://static.wixstatic.com'
            ],
            ...options
        };
        
        this.messageHandlers = new Map();
        this.connectionStatus = 'disconnected';
        this.parentOrigin = null;
        
        if (this.options.autoInit) {
            this.initialize();
        }
    }
    
    /**
     * Initialize the communication controller
     */
    initialize() {
        this.log('Initializing Velo Communication Controller for:', this.componentName);
        
        // Set up message listener
        window.addEventListener('message', this.handleIncomingMessage.bind(this));
        
        // Register default message handlers
        this.registerDefaultHandlers();
        
        // Send connection request to parent
        this.requestConnection();
        
        // Set up heartbeat
        this.startHeartbeat();
        
        this.log('Velo Communication Controller initialized');
    }
    
    /**
     * Register default message handlers
     */
    registerDefaultHandlers() {
        // Connection acknowledgment
        this.registerHandler('GFE_CONNECTION_ACK', (data, origin) => {
            this.connectionStatus = 'connected';
            this.parentOrigin = origin;
            this.log('Connection established with parent:', origin);
            this.onConnectionEstablished(data);
        });
        
        // Heartbeat response
        this.registerHandler('GFE_HEARTBEAT_RESPONSE', (data) => {
            this.log('Heartbeat acknowledged');
        });
        
        // Configuration updates
        this.registerHandler('GFE_CONFIG_UPDATE', (data) => {
            this.log('Configuration update received:', data);
            this.onConfigUpdate(data);
        });
        
        // Data requests
        this.registerHandler('GFE_DATA_REQUEST', (data) => {
            this.log('Data request received:', data);
            this.onDataRequest(data);
        });
        
        // Lead capture requests
        this.registerHandler('GFE_LEAD_CAPTURE_REQUEST', (data) => {
            this.log('Lead capture request received:', data);
            this.onLeadCaptureRequest(data);
        });
        
        // Error notifications
        this.registerHandler('GFE_ERROR_NOTIFICATION', (data) => {
            this.log('Error notification received:', data);
            this.onErrorNotification(data);
        });
    }
    
    /**
     * Handle incoming postMessage events
     */
    handleIncomingMessage(event) {
        // Validate origin
        if (!this.isOriginTrusted(event.origin)) {
            this.log('Message rejected from untrusted origin:', event.origin);
            return;
        }
        
        // Validate message structure
        if (!this.isValidMessage(event.data)) {
            this.log('Invalid message structure:', event.data);
            return;
        }
        
        const { source, type, data } = event.data;
        
        this.log('Received message:', { source, type, data });
        
        // Handle the message
        if (this.messageHandlers.has(type)) {
            try {
                this.messageHandlers.get(type)(data, event.origin);
            } catch (error) {
                this.log('Error handling message:', error);
                this.sendErrorNotification('MESSAGE_HANDLER_ERROR', error.message);
            }
        } else {
            this.log('No handler registered for message type:', type);
        }
    }
    
    /**
     * Register a message handler
     */
    registerHandler(messageType, handler) {
        this.messageHandlers.set(messageType, handler);
        this.log('Registered handler for:', messageType);
    }
    
    /**
     * Send a message to the parent window
     */
    sendMessage(type, data = {}, targetOrigin = '*') {
        const message = {
            source: this.componentName,
            type: type,
            data: data,
            timestamp: Date.now()
        };
        
        this.log('Sending message:', message);
        
        if (window.parent && window.parent !== window) {
            window.parent.postMessage(message, targetOrigin);
        } else {
            this.log('No parent window available');
        }
    }
    
    /**
     * Request connection with parent
     */
    requestConnection() {
        this.sendMessage('GFE_CONNECTION_REQUEST', {
            component: this.componentName,
            capabilities: this.getComponentCapabilities(),
            version: '2.0.0'
        });
    }
    
    /**
     * Start heartbeat to maintain connection
     */
    startHeartbeat() {
        setInterval(() => {
            if (this.connectionStatus === 'connected') {
                this.sendMessage('GFE_HEARTBEAT', {
                    component: this.componentName,
                    status: 'active',
                    timestamp: Date.now()
                });
            }
        }, 30000); // Every 30 seconds
    }
    
    /**
     * Send component ready notification
     */
    notifyReady() {
        this.sendMessage('GFE_COMPONENT_READY', {
            component: this.componentName,
            capabilities: this.getComponentCapabilities(),
            status: 'ready'
        });
    }
    
    /**
     * Send lead capture data
     */
    sendLeadCapture(leadData) {
        this.sendMessage('GFE_LEAD_CAPTURE', {
            component: this.componentName,
            leadData: leadData,
            timestamp: Date.now()
        });
    }
    
    /**
     * Send error notification
     */
    sendErrorNotification(errorType, errorMessage, errorData = {}) {
        this.sendMessage('GFE_ERROR_NOTIFICATION', {
            component: this.componentName,
            errorType: errorType,
            errorMessage: errorMessage,
            errorData: errorData,
            timestamp: Date.now()
        });
    }
    
    /**
     * Send data update
     */
    sendDataUpdate(dataType, data) {
        this.sendMessage('GFE_DATA_UPDATE', {
            component: this.componentName,
            dataType: dataType,
            data: data,
            timestamp: Date.now()
        });
    }
    
    /**
     * Request data from parent
     */
    requestData(dataType, parameters = {}) {
        this.sendMessage('GFE_DATA_REQUEST', {
            component: this.componentName,
            dataType: dataType,
            parameters: parameters,
            timestamp: Date.now()
        });
    }
    
    /**
     * Validate if origin is trusted
     */
    isOriginTrusted(origin) {
        if (!origin) return false;
        
        return this.options.trustedOrigins.some(trustedOrigin => {
            if (trustedOrigin === '*') return true;
            return origin === trustedOrigin || 
                   origin.endsWith('.wix.com') ||
                   origin.includes('localhost') ||
                   origin.includes('127.0.0.1');
        });
    }
    
    /**
     * Validate message structure
     */
    isValidMessage(message) {
        return message && 
               typeof message === 'object' &&
               typeof message.source === 'string' &&
               typeof message.type === 'string';
    }
    
    /**
     * Get component capabilities
     */
    getComponentCapabilities() {
        const baseCapabilities = [
            'message_communication',
            'error_handling',
            'heartbeat',
            'data_exchange'
        ];
        
        // Add component-specific capabilities
        switch (this.componentName) {
            case 'gfe-home-page':
                return [...baseCapabilities, 'lead_capture', 'ai_advisor', 'navigation'];
            case 'gfe-good-faith-estimator':
                return [...baseCapabilities, 'pricing', 'quotes', 'product_selection'];
            case 'gfe-ai-window-measure':
                return [...baseCapabilities, 'image_analysis', 'measurement', 'ai_processing'];
            case 'gfe-ai-chat-agent':
                return [...baseCapabilities, 'chat', 'product_recommendations', 'ai_responses'];
            case 'gfe-window-products-browser':
                return [...baseCapabilities, 'product_display', 'filtering', 'product_selection'];
            default:
                return baseCapabilities;
        }
    }
    
    /**
     * Event handlers (to be overridden by components)
     */
    onConnectionEstablished(data) {
        this.log('Connection established, override this method for custom handling');
    }
    
    onConfigUpdate(data) {
        this.log('Config update received, override this method for custom handling');
    }
    
    onDataRequest(data) {
        this.log('Data request received, override this method for custom handling');
    }
    
    onLeadCaptureRequest(data) {
        this.log('Lead capture request received, override this method for custom handling');
    }
    
    onErrorNotification(data) {
        this.log('Error notification received, override this method for custom handling');
    }
    
    /**
     * Logging utility
     */
    log(...args) {
        if (this.options.enableLogging) {
            console.log(`[GFE-Velo-${this.componentName}]`, ...args);
        }
    }
    
    /**
     * Get connection status
     */
    getConnectionStatus() {
        return this.connectionStatus;
    }
    
    /**
     * Destroy the controller
     */
    destroy() {
        window.removeEventListener('message', this.handleIncomingMessage.bind(this));
        this.messageHandlers.clear();
        this.connectionStatus = 'disconnected';
        this.log('Velo Communication Controller destroyed');
    }
}

// Export for use in other components
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GFEVeloCommunicationController;
} else if (typeof window !== 'undefined') {
    window.GFEVeloCommunicationController = GFEVeloCommunicationController;
}

/**
 * ========================================================================
 * VELO PARENT PAGE INTEGRATION GUIDE
 * ========================================================================
 * 
 * To integrate with Wix Velo on the parent page, add this code to your page:
 * 
 * // In your Wix page code (e.g., Home page)
 * import wixWindow from 'wix-window';
 * import wixData from 'wix-data';
 * 
 * $w.onReady(() => {
 *     // Listen for iframe messages
 *     wixWindow.postMessage.onMessage((message) => {
 *         console.log('Received message from iframe:', message);
 *         
 *         switch (message.type) {
 *             case 'GFE_CONNECTION_REQUEST':
 *                 handleConnectionRequest(message);
 *                 break;
 *             case 'GFE_LEAD_CAPTURE':
 *                 handleLeadCapture(message);
 *                 break;
 *             case 'GFE_DATA_REQUEST':
 *                 handleDataRequest(message);
 *                 break;
 *             // Add more cases as needed
 *         }
 *     });
 * 
 *     function handleConnectionRequest(message) {
 *         // Send acknowledgment
 *         $w('#yourIframeId').postMessage({
 *             source: 'wix-parent',
 *             type: 'GFE_CONNECTION_ACK',
 *             data: { status: 'connected' }
 *         });
 *     }
 * 
 *     function handleLeadCapture(message) {
 *         // Save to Wix collection
 *         wixData.save('CRMLeads', message.data.leadData)
 *             .then((result) => {
 *                 console.log('Lead saved:', result);
 *             })
 *             .catch((error) => {
 *                 console.error('Error saving lead:', error);
 *             });
 *     }
 * 
 *     function handleDataRequest(message) {
 *         // Handle data requests from iframe
 *         if (message.data.dataType === 'windowProducts') {
 *             wixData.query('WindowProducts')
 *                 .find()
 *                 .then((results) => {
 *                     $w('#yourIframeId').postMessage({
 *                         source: 'wix-parent',
 *                         type: 'GFE_DATA_RESPONSE',
 *                         data: { products: results.items }
 *                     });
 *                 });
 *         }
 *     }
 * });
 */

