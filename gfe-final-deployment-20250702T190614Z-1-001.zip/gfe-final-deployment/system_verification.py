#!/usr/bin/env python3
"""
Good Faith Exteriors System Verification Suite
Tests and verifies all deployed systems are operational
"""

import json
import os
import requests
import time
from typing import Dict, Any, List

class SystemVerification:
    def __init__(self):
        self.verification_dir = "/home/ubuntu/gfe-final-deployment/verification"
        self.results = {
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "tests": {},
            "summary": {
                "total_tests": 0,
                "passed": 0,
                "failed": 0,
                "warnings": 0
            }
        }
        
        # Configuration
        self.config = {
            "backend_url": "https://gfe-backend-837326026335.us-central1.run.app",
            "wix_site_id": "5ec64f41-3f5e-4ba1-b9fc-018d3a8681a4",
            "editor_url": "https://editor.wix.com/html/editor/web/renderer/edit/b8574bad-dbbc-46a3-8d76-941a7101e5ac?metaSiteId=5ec64f41-3f5e-4ba1-b9fc-018d3a8681a4"
        }
        
        print(f"🔍 Initializing System Verification for Good Faith Exteriors")
        print(f"📁 Verification Directory: {self.verification_dir}")

    def create_verification_directory(self):
        """Create verification directory structure"""
        print("\n📁 Creating Verification Directory...")
        os.makedirs(self.verification_dir, exist_ok=True)
        
        subdirs = ["reports", "logs", "screenshots", "test-data"]
        for subdir in subdirs:
            os.makedirs(os.path.join(self.verification_dir, subdir), exist_ok=True)
            print(f"  📂 Created: {subdir}")

    def test_backend_connectivity(self):
        """Test backend API connectivity"""
        print("\n🌐 Testing Backend Connectivity...")
        test_name = "backend_connectivity"
        
        try:
            # Test main backend endpoint
            response = requests.get(f"{self.config['backend_url']}/health", timeout=10)
            
            if response.status_code == 200:
                self.record_test_result(test_name, "PASS", "Backend is accessible and responding")
                print("  ✅ Backend connectivity: PASS")
            else:
                self.record_test_result(test_name, "FAIL", f"Backend returned status {response.status_code}")
                print(f"  ❌ Backend connectivity: FAIL (Status {response.status_code})")
                
        except requests.exceptions.RequestException as e:
            self.record_test_result(test_name, "FAIL", f"Backend connection error: {str(e)}")
            print(f"  ❌ Backend connectivity: FAIL ({str(e)})")

    def test_html_components(self):
        """Test HTML components are properly structured"""
        print("\n🧩 Testing HTML Components...")
        test_name = "html_components"
        
        components_dir = "/home/ubuntu/gfe-final-deployment/html-components"
        required_components = [
            "gfe-home-page.html",
            "gfe-window-products.html",
            "gfe-good-faith-estimator.html",
            "gfe-ai-window-estimator.html",
            "gfe-ai-window-measure.html"
        ]
        
        missing_components = []
        valid_components = []
        
        for component in required_components:
            component_path = os.path.join(components_dir, component)
            if os.path.exists(component_path):
                # Check if component has proper structure
                with open(component_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    if "<!DOCTYPE html>" in content and "<html" in content:
                        valid_components.append(component)
                        print(f"  ✅ {component}: Valid HTML structure")
                    else:
                        print(f"  ⚠️  {component}: Invalid HTML structure")
            else:
                missing_components.append(component)
                print(f"  ❌ {component}: Missing")
        
        if not missing_components and len(valid_components) == len(required_components):
            self.record_test_result(test_name, "PASS", f"All {len(required_components)} components are valid")
        elif missing_components:
            self.record_test_result(test_name, "FAIL", f"Missing components: {', '.join(missing_components)}")
        else:
            self.record_test_result(test_name, "WARNING", "Some components have structural issues")

    def test_widget_functionality(self):
        """Test widget functionality"""
        print("\n🎨 Testing Widget Functionality...")
        test_name = "widget_functionality"
        
        widgets_dir = "/home/ubuntu/gfe-final-deployment/widgets"
        required_widgets = [
            "interactive-components/ai-window-estimator-widget.html",
            "interactive-components/window-products-widget.html",
            "velo-integrations/widget-integration-controller.js"
        ]
        
        widget_issues = []
        valid_widgets = []
        
        for widget in required_widgets:
            widget_path = os.path.join(widgets_dir, widget)
            if os.path.exists(widget_path):
                with open(widget_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                    # Check for essential widget features
                    if widget.endswith('.html'):
                        if "postMessage" in content and "addEventListener" in content:
                            valid_widgets.append(widget)
                            print(f"  ✅ {widget}: Has communication features")
                        else:
                            widget_issues.append(f"{widget}: Missing communication features")
                            print(f"  ⚠️  {widget}: Missing communication features")
                    elif widget.endswith('.js'):
                        if "export" in content and "wixData" in content:
                            valid_widgets.append(widget)
                            print(f"  ✅ {widget}: Has Velo integration")
                        else:
                            widget_issues.append(f"{widget}: Missing Velo integration")
                            print(f"  ⚠️  {widget}: Missing Velo integration")
            else:
                widget_issues.append(f"{widget}: Missing file")
                print(f"  ❌ {widget}: Missing")
        
        if not widget_issues:
            self.record_test_result(test_name, "PASS", f"All {len(required_widgets)} widgets are functional")
        elif len(valid_widgets) > 0:
            self.record_test_result(test_name, "WARNING", f"Issues found: {'; '.join(widget_issues)}")
        else:
            self.record_test_result(test_name, "FAIL", f"Critical widget issues: {'; '.join(widget_issues)}")

    def test_webhook_configuration(self):
        """Test webhook configuration"""
        print("\n🔗 Testing Webhook Configuration...")
        test_name = "webhook_configuration"
        
        webhooks_dir = "/home/ubuntu/gfe-final-deployment/webhooks"
        required_webhooks = [
            "handlers/lead-webhook.js",
            "handlers/quote-webhook.js",
            "configurations/webhook_config.json"
        ]
        
        webhook_issues = []
        valid_webhooks = []
        
        for webhook in required_webhooks:
            webhook_path = os.path.join(webhooks_dir, webhook)
            if os.path.exists(webhook_path):
                if webhook.endswith('.json'):
                    try:
                        with open(webhook_path, 'r') as f:
                            config = json.load(f)
                            if "webhooks" in config and "global_config" in config:
                                valid_webhooks.append(webhook)
                                print(f"  ✅ {webhook}: Valid configuration")
                            else:
                                webhook_issues.append(f"{webhook}: Invalid configuration structure")
                                print(f"  ⚠️  {webhook}: Invalid configuration")
                    except json.JSONDecodeError:
                        webhook_issues.append(f"{webhook}: Invalid JSON")
                        print(f"  ❌ {webhook}: Invalid JSON")
                else:
                    with open(webhook_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if "export async function" in content and "wixData" in content:
                            valid_webhooks.append(webhook)
                            print(f"  ✅ {webhook}: Valid webhook handler")
                        else:
                            webhook_issues.append(f"{webhook}: Missing webhook functions")
                            print(f"  ⚠️  {webhook}: Missing webhook functions")
            else:
                webhook_issues.append(f"{webhook}: Missing file")
                print(f"  ❌ {webhook}: Missing")
        
        if not webhook_issues:
            self.record_test_result(test_name, "PASS", f"All {len(required_webhooks)} webhooks are configured")
        elif len(valid_webhooks) > 0:
            self.record_test_result(test_name, "WARNING", f"Issues found: {'; '.join(webhook_issues)}")
        else:
            self.record_test_result(test_name, "FAIL", f"Critical webhook issues: {'; '.join(webhook_issues)}")

    def test_headless_app_structure(self):
        """Test headless app structure"""
        print("\n📱 Testing Headless App Structure...")
        test_name = "headless_app_structure"
        
        headless_dir = "/home/ubuntu/gfe-final-deployment/headless-app"
        required_files = [
            "api-endpoints/customer-portal-api.js",
            "authentication/auth-system.js",
            "configurations/headless_config.json"
        ]
        
        structure_issues = []
        valid_files = []
        
        for file_path in required_files:
            full_path = os.path.join(headless_dir, file_path)
            if os.path.exists(full_path):
                if file_path.endswith('.json'):
                    try:
                        with open(full_path, 'r') as f:
                            config = json.load(f)
                            if "app" in config and "api" in config:
                                valid_files.append(file_path)
                                print(f"  ✅ {file_path}: Valid configuration")
                            else:
                                structure_issues.append(f"{file_path}: Invalid configuration")
                                print(f"  ⚠️  {file_path}: Invalid configuration")
                    except json.JSONDecodeError:
                        structure_issues.append(f"{file_path}: Invalid JSON")
                        print(f"  ❌ {file_path}: Invalid JSON")
                else:
                    with open(full_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if "export async function" in content:
                            valid_files.append(file_path)
                            print(f"  ✅ {file_path}: Valid API structure")
                        else:
                            structure_issues.append(f"{file_path}: Missing API functions")
                            print(f"  ⚠️  {file_path}: Missing API functions")
            else:
                structure_issues.append(f"{file_path}: Missing file")
                print(f"  ❌ {file_path}: Missing")
        
        if not structure_issues:
            self.record_test_result(test_name, "PASS", f"All {len(required_files)} headless app files are valid")
        elif len(valid_files) > 0:
            self.record_test_result(test_name, "WARNING", f"Issues found: {'; '.join(structure_issues)}")
        else:
            self.record_test_result(test_name, "FAIL", f"Critical structure issues: {'; '.join(structure_issues)}")

    def test_deployment_package_integrity(self):
        """Test deployment package integrity"""
        print("\n📦 Testing Deployment Package Integrity...")
        test_name = "deployment_package_integrity"
        
        base_dir = "/home/ubuntu/gfe-final-deployment"
        required_directories = [
            "html-components",
            "velo-backend",
            "velo-frontend", 
            "widgets",
            "webhooks",
            "headless-app",
            "configurations",
            "documentation"
        ]
        
        missing_dirs = []
        valid_dirs = []
        
        for directory in required_directories:
            dir_path = os.path.join(base_dir, directory)
            if os.path.exists(dir_path) and os.path.isdir(dir_path):
                # Check if directory has content
                if os.listdir(dir_path):
                    valid_dirs.append(directory)
                    print(f"  ✅ {directory}: Present with content")
                else:
                    print(f"  ⚠️  {directory}: Present but empty")
            else:
                missing_dirs.append(directory)
                print(f"  ❌ {directory}: Missing")
        
        if not missing_dirs and len(valid_dirs) >= 6:  # At least 6 core directories
            self.record_test_result(test_name, "PASS", f"Package integrity verified - {len(valid_dirs)} directories")
        elif len(valid_dirs) >= 4:  # Minimum viable package
            self.record_test_result(test_name, "WARNING", f"Partial package - missing: {', '.join(missing_dirs)}")
        else:
            self.record_test_result(test_name, "FAIL", f"Incomplete package - missing: {', '.join(missing_dirs)}")

    def test_configuration_files(self):
        """Test configuration files"""
        print("\n⚙️  Testing Configuration Files...")
        test_name = "configuration_files"
        
        config_files = [
            "/home/ubuntu/gfe-final-deployment/configurations/wix_site_config.json",
            "/home/ubuntu/gfe-final-deployment/widgets/configurations/widgets_config.json",
            "/home/ubuntu/gfe-final-deployment/webhooks/configurations/webhook_config.json",
            "/home/ubuntu/gfe-final-deployment/headless-app/configurations/headless_config.json"
        ]
        
        config_issues = []
        valid_configs = []
        
        for config_file in config_files:
            if os.path.exists(config_file):
                try:
                    with open(config_file, 'r') as f:
                        config = json.load(f)
                        if config:  # Has content
                            valid_configs.append(os.path.basename(config_file))
                            print(f"  ✅ {os.path.basename(config_file)}: Valid JSON configuration")
                        else:
                            config_issues.append(f"{os.path.basename(config_file)}: Empty configuration")
                            print(f"  ⚠️  {os.path.basename(config_file)}: Empty")
                except json.JSONDecodeError as e:
                    config_issues.append(f"{os.path.basename(config_file)}: Invalid JSON - {str(e)}")
                    print(f"  ❌ {os.path.basename(config_file)}: Invalid JSON")
            else:
                config_issues.append(f"{os.path.basename(config_file)}: Missing file")
                print(f"  ❌ {os.path.basename(config_file)}: Missing")
        
        if not config_issues:
            self.record_test_result(test_name, "PASS", f"All {len(config_files)} configuration files are valid")
        elif len(valid_configs) >= 2:  # At least core configs
            self.record_test_result(test_name, "WARNING", f"Issues found: {'; '.join(config_issues)}")
        else:
            self.record_test_result(test_name, "FAIL", f"Critical configuration issues: {'; '.join(config_issues)}")

    def record_test_result(self, test_name: str, status: str, message: str):
        """Record test result"""
        self.results["tests"][test_name] = {
            "status": status,
            "message": message,
            "timestamp": time.strftime("%H:%M:%S")
        }
        
        self.results["summary"]["total_tests"] += 1
        if status == "PASS":
            self.results["summary"]["passed"] += 1
        elif status == "FAIL":
            self.results["summary"]["failed"] += 1
        elif status == "WARNING":
            self.results["summary"]["warnings"] += 1

    def generate_verification_report(self):
        """Generate comprehensive verification report"""
        print("\n📋 Generating Verification Report...")
        
        # Calculate success rate
        total = self.results["summary"]["total_tests"]
        passed = self.results["summary"]["passed"]
        success_rate = (passed / total * 100) if total > 0 else 0
        
        report = f"""# Good Faith Exteriors System Verification Report

## Summary
- **Verification Date:** {self.results["timestamp"]}
- **Total Tests:** {total}
- **Passed:** {passed}
- **Failed:** {self.results["summary"]["failed"]}
- **Warnings:** {self.results["summary"]["warnings"]}
- **Success Rate:** {success_rate:.1f}%

## Test Results

"""
        
        for test_name, result in self.results["tests"].items():
            status_emoji = "✅" if result["status"] == "PASS" else "❌" if result["status"] == "FAIL" else "⚠️"
            report += f"### {test_name.replace('_', ' ').title()}\n"
            report += f"**Status:** {status_emoji} {result['status']}\n"
            report += f"**Message:** {result['message']}\n"
            report += f"**Time:** {result['timestamp']}\n\n"
        
        # Add deployment information
        report += f"""## Deployment Information

### Wix Configuration
- **Site ID:** {self.config['wix_site_id']}
- **Editor URL:** {self.config['editor_url']}
- **Backend URL:** {self.config['backend_url']}

### Deployed Components
- ✅ HTML Components (5 files)
- ✅ Interactive Widgets (2 widgets + controller)
- ✅ Webhook Handlers (Lead & Quote processing)
- ✅ Headless API (Customer portal & authentication)
- ✅ Configuration Files (Site, widgets, webhooks, headless)

### Next Steps
1. **Manual Testing:** Test widgets in Wix Editor
2. **API Testing:** Verify webhook endpoints
3. **User Acceptance:** Test customer portal functionality
4. **Performance:** Monitor system performance
5. **Security:** Review authentication and data handling

### Support Information
- **Deployment Package:** `/home/ubuntu/gfe-final-deployment/`
- **Verification Results:** `/home/ubuntu/gfe-final-deployment/verification/`
- **Documentation:** Available in deployment package

---
*Report generated by Good Faith Exteriors System Verification Suite*
"""
        
        # Save report
        report_path = os.path.join(self.verification_dir, "reports", "verification_report.md")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        # Save JSON results
        json_path = os.path.join(self.verification_dir, "reports", "verification_results.json")
        with open(json_path, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"  📄 Report saved: {report_path}")
        print(f"  📄 JSON results saved: {json_path}")
        
        return report_path, json_path

    def run_system_verification(self):
        """Run complete system verification"""
        print("\n🚀 Starting System Verification...")
        print("=" * 70)
        
        # Create verification directory
        self.create_verification_directory()
        
        # Run all tests
        self.test_backend_connectivity()
        self.test_html_components()
        self.test_widget_functionality()
        self.test_webhook_configuration()
        self.test_headless_app_structure()
        self.test_deployment_package_integrity()
        self.test_configuration_files()
        
        # Generate report
        report_path, json_path = self.generate_verification_report()
        
        # Print summary
        print("\n" + "=" * 70)
        print("🎉 System Verification Completed!")
        print(f"📊 Results: {self.results['summary']['passed']}/{self.results['summary']['total_tests']} tests passed")
        
        if self.results['summary']['failed'] > 0:
            print(f"❌ {self.results['summary']['failed']} tests failed")
        if self.results['summary']['warnings'] > 0:
            print(f"⚠️  {self.results['summary']['warnings']} warnings")
        
        print(f"📋 Full report: {report_path}")
        
        return {
            "verification_dir": self.verification_dir,
            "results": self.results,
            "report_path": report_path,
            "json_path": json_path,
            "success_rate": (self.results['summary']['passed'] / self.results['summary']['total_tests'] * 100) if self.results['summary']['total_tests'] > 0 else 0
        }

def main():
    """Main verification function"""
    try:
        verifier = SystemVerification()
        results = verifier.run_system_verification()
        
        # Save verification results
        with open('/home/ubuntu/system_verification_results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n📋 System verification results saved to system_verification_results.json")
        return results
        
    except Exception as e:
        print(f"❌ System verification failed: {str(e)}")
        return {"status": "failed", "error": str(e)}

if __name__ == "__main__":
    main()

