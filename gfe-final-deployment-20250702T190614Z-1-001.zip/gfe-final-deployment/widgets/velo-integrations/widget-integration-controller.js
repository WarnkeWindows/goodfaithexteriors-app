// Good Faith Exteriors - Velo Widget Integration Controller
// Handles communication between HTML widgets and Wix Velo

import wixData from 'wix-data';
import wixLocation from 'wix-location';

// Configuration
const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";
const WIDGET_CONFIG = {
    ai_estimator: {
        elementId: '#aiEstimatorWidget',
        collection: 'GFE_Leads'
    },
    window_products: {
        elementId: '#windowProductsWidget',
        collection: 'GFE_WindowProducts'
    },
    quote_builder: {
        elementId: '#quoteBuilderWidget',
        collection: 'GFE_Quotes'
    }
};

// Widget Communication Handler
export function initializeWidgetCommunication() {
    console.log('Initializing GFE Widget Communication...');
    
    // Listen for messages from widgets
    if (typeof window !== 'undefined') {
        window.addEventListener('message', handleWidgetMessage);
    }
    
    // Initialize each widget
    Object.keys(WIDGET_CONFIG).forEach(widgetType => {
        initializeWidget(widgetType);
    });
}

function handleWidgetMessage(event) {
    console.log('Widget message received:', event.data);
    
    const { type, data } = event.data;
    
    switch (type) {
        case 'ai_analysis_complete':
            handleAIAnalysisComplete(data);
            break;
            
        case 'product_selected':
            handleProductSelected(data);
            break;
            
        case 'request_quote':
            handleQuoteRequest(data);
            break;
            
        case 'view_product_details':
            handleViewProductDetails(data);
            break;
            
        default:
            console.log('Unknown widget message type:', type);
    }
}

async function handleAIAnalysisComplete(analysisData) {
    console.log('AI Analysis completed:', analysisData);
    
    try {
        // Save analysis result to Wix Data
        const leadData = {
            leadId: generateLeadId(),
            source: 'ai_estimator',
            projectType: 'window_replacement',
            windowType: analysisData.window_type,
            estimatedCost: analysisData.estimated_cost,
            analysisData: JSON.stringify(analysisData),
            createdDate: new Date(),
            status: 'new'
        };
        
        await wixData.save('GFE_Leads', leadData);
        
        // Show success message
        showNotification('Analysis saved! Would you like to get a detailed quote?', 'success');
        
        // Optionally redirect to quote page
        if (analysisData.estimated_cost > 0) {
            setTimeout(() => {
                wixLocation.to('/quote-builder?analysis=' + encodeURIComponent(JSON.stringify(analysisData)));
            }, 2000);
        }
        
    } catch (error) {
        console.error('Error saving analysis:', error);
        showNotification('Error saving analysis. Please try again.', 'error');
    }
}

async function handleProductSelected(productData) {
    console.log('Product selected:', productData);
    
    try {
        // Update product view count
        await updateProductViews(productData.id);
        
        // Show product details in lightbox or modal
        showProductDetails(productData);
        
    } catch (error) {
        console.error('Error handling product selection:', error);
    }
}

async function handleQuoteRequest(requestData) {
    console.log('Quote requested:', requestData);
    
    try {
        // Create quote request in Wix Data
        const quoteData = {
            quoteId: generateQuoteId(),
            source: requestData.source,
            requestData: JSON.stringify(requestData),
            status: 'pending',
            createdDate: new Date()
        };
        
        if (requestData.product) {
            quoteData.productId = requestData.product.id;
            quoteData.productBrand = requestData.product.brand;
            quoteData.productType = requestData.product.windowType;
            quoteData.estimatedPrice = requestData.product.basePrice;
        }
        
        await wixData.save('GFE_Quotes', quoteData);
        
        // Redirect to quote form
        wixLocation.to('/quote-form?request=' + encodeURIComponent(JSON.stringify(requestData)));
        
    } catch (error) {
        console.error('Error creating quote request:', error);
        showNotification('Error creating quote request. Please try again.', 'error');
    }
}

function handleViewProductDetails(productData) {
    console.log('View product details:', productData);
    
    // Open product details page or modal
    wixLocation.to('/product-details?id=' + productData.id);
}

function initializeWidget(widgetType) {
    const config = WIDGET_CONFIG[widgetType];
    const widget = $w(config.elementId);
    
    if (widget) {
        console.log(`Initializing ${widgetType} widget`);
        
        // Configure widget settings
        widget.onMessage((event) => {
            handleWidgetMessage(event);
        });
        
        // Send initial configuration to widget
        widget.postMessage({
            type: 'configure',
            config: {
                backendUrl: BACKEND_URL,
                widgetType: widgetType,
                collection: config.collection
            }
        });
    }
}

async function updateProductViews(productId) {
    try {
        const product = await wixData.get('GFE_WindowProducts', productId);
        if (product) {
            const viewCount = (product.viewCount || 0) + 1;
            await wixData.update('GFE_WindowProducts', {
                _id: productId,
                viewCount: viewCount,
                lastViewed: new Date()
            });
        }
    } catch (error) {
        console.error('Error updating product views:', error);
    }
}

function showProductDetails(productData) {
    // Implementation depends on your site structure
    // Could open a lightbox, modal, or navigate to details page
    console.log('Showing product details for:', productData);
}

function showNotification(message, type = 'info') {
    // Implementation depends on your notification system
    console.log(`${type.toUpperCase()}: ${message}`);
    
    // Example: Show in a Wix element
    if ($w('#notificationBar')) {
        $w('#notificationBar').text = message;
        $w('#notificationBar').show();
        
        setTimeout(() => {
            $w('#notificationBar').hide();
        }, 5000);
    }
}

function generateLeadId() {
    return 'lead_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function generateQuoteId() {
    return 'quote_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// Export functions for use in page code
export {
    handleAIAnalysisComplete,
    handleProductSelected,
    handleQuoteRequest,
    handleViewProductDetails,
    showNotification
};