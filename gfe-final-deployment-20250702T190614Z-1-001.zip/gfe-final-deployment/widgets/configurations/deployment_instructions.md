# Widget Deployment Instructions

## Overview
This directory contains interactive widgets for the Good Faith Exteriors website.

## Widget Components

### 1. AI Window Estimator Widget
- **File:** `interactive-components/ai-window-estimator-widget.html`
- **Purpose:** AI-powered window analysis and cost estimation
- **Wix Element ID:** `#aiEstimatorWidget`
- **Collection:** `GFE_Leads`

### 2. Window Products Widget
- **File:** `interactive-components/window-products-widget.html`
- **Purpose:** Interactive product catalog and browser
- **Wix Element ID:** `#windowProductsWidget`
- **Collection:** `GFE_WindowProducts`

## Deployment Steps

### 1. Upload Widget HTML Files
1. Copy widget HTML files to your Wix site
2. Add HTML components to appropriate pages
3. Assign the correct element IDs

### 2. Deploy Velo Integration
1. Copy `velo-integrations/widget-integration-controller.js` to your Velo backend
2. Import and initialize in your page code:
   ```javascript
   import { initializeWidgetCommunication } from 'backend/widget-integration-controller';
   
   $w.onReady(function () {
       initializeWidgetCommunication();
   });
   ```

### 3. Configure Widget Communication
1. Ensure HTML components have message event handlers enabled
2. Set up proper element IDs in Wix Editor
3. Test widget-to-Velo communication

### 4. Test Widget Functionality
1. Test AI analysis functionality
2. Test product browsing and filtering
3. Test quote request generation
4. Verify data saving to collections

## Widget Features

### AI Window Estimator
- ✅ Drag & drop image upload
- ✅ AI-powered window analysis
- ✅ Cost estimation
- ✅ Quote request generation
- ✅ Wix Data integration

### Window Products Browser
- ✅ Product filtering by brand, type, material
- ✅ Price range filtering
- ✅ Interactive product cards
- ✅ Quote request functionality
- ✅ Product detail viewing

## Configuration

All widgets are configured via the `configurations/widgets_config.json` file.
Update this file to modify:
- Backend API endpoints
- Wix site configuration
- Theme colors and styling
- Asset URLs

## Support

For technical support with widget deployment:
1. Check browser console for error messages
2. Verify API endpoint connectivity
3. Ensure Wix Data collections are properly configured
4. Test widget communication with parent page
