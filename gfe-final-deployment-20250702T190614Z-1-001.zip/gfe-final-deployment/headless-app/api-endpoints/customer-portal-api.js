// Good Faith Exteriors - Customer Portal API
// Headless API for customer portal functionality

import wixData from 'wix-data';
import { fetch } from 'wix-fetch';

const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";

// Get customer projects
export async function get_customerProjects(request) {
    try {
        const customerId = request.query.customerId;
        
        if (!customerId) {
            return {
                status: 400,
                body: { error: 'Customer ID is required' }
            };
        }
        
        // Get customer projects from Wix Data
        const projects = await wixData.query('GFE_Projects')
            .eq('customerId', customerId)
            .descending('createdDate')
            .find();
        
        // Get related quotes
        const projectIds = projects.items.map(p => p._id);
        const quotes = await wixData.query('GFE_Quotes')
            .hasSome('projectId', projectIds)
            .find();
        
        // Combine data
        const projectsWithQuotes = projects.items.map(project => ({
            ...project,
            quotes: quotes.items.filter(q => q.projectId === project._id)
        }));
        
        return {
            status: 200,
            body: {
                success: true,
                projects: projectsWithQuotes,
                totalProjects: projects.totalCount
            }
        };
        
    } catch (error) {
        console.error('Customer projects API error:', error);
        return {
            status: 500,
            body: { error: error.message }
        };
    }
}

// Get customer quotes
export async function get_customerQuotes(request) {
    try {
        const customerId = request.query.customerId;
        
        if (!customerId) {
            return {
                status: 400,
                body: { error: 'Customer ID is required' }
            };
        }
        
        const quotes = await wixData.query('GFE_Quotes')
            .eq('customerId', customerId)
            .descending('createdDate')
            .find();
        
        return {
            status: 200,
            body: {
                success: true,
                quotes: quotes.items,
                totalQuotes: quotes.totalCount
            }
        };
        
    } catch (error) {
        console.error('Customer quotes API error:', error);
        return {
            status: 500,
            body: { error: error.message }
        };
    }
}

// Submit customer feedback
export async function post_customerFeedback(request) {
    try {
        const feedbackData = await request.body.json();
        
        // Validate required fields
        if (!feedbackData.customerId || !feedbackData.rating || !feedbackData.comments) {
            return {
                status: 400,
                body: { error: 'Customer ID, rating, and comments are required' }
            };
        }
        
        // Save feedback to Wix Data
        const feedback = await wixData.save('GFE_CustomerFeedback', {
            ...feedbackData,
            submittedDate: new Date(),
            status: 'new'
        });
        
        // Send notification to team
        await notifyTeamOfFeedback(feedback);
        
        return {
            status: 200,
            body: {
                success: true,
                message: 'Feedback submitted successfully',
                feedbackId: feedback._id
            }
        };
        
    } catch (error) {
        console.error('Customer feedback API error:', error);
        return {
            status: 500,
            body: { error: error.message }
        };
    }
}

// Schedule appointment
export async function post_scheduleAppointment(request) {
    try {
        const appointmentData = await request.body.json();
        
        // Validate required fields
        if (!appointmentData.customerId || !appointmentData.preferredDate || !appointmentData.serviceType) {
            return {
                status: 400,
                body: { error: 'Customer ID, preferred date, and service type are required' }
            };
        }
        
        // Check availability
        const isAvailable = await checkAppointmentAvailability(appointmentData.preferredDate);
        
        if (!isAvailable) {
            return {
                status: 409,
                body: { error: 'Requested time slot is not available' }
            };
        }
        
        // Create appointment
        const appointment = await wixData.save('GFE_Appointments', {
            ...appointmentData,
            status: 'scheduled',
            createdDate: new Date()
        });
        
        // Send confirmation
        await sendAppointmentConfirmation(appointment);
        
        return {
            status: 200,
            body: {
                success: true,
                message: 'Appointment scheduled successfully',
                appointmentId: appointment._id
            }
        };
        
    } catch (error) {
        console.error('Schedule appointment API error:', error);
        return {
            status: 500,
            body: { error: error.message }
        };
    }
}

async function notifyTeamOfFeedback(feedback) {
    try {
        await fetch(`${BACKEND_URL}/api/notifications/feedback`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'api-key'
            },
            body: JSON.stringify(feedback)
        });
    } catch (error) {
        console.error('Feedback notification error:', error);
    }
}

async function checkAppointmentAvailability(preferredDate) {
    try {
        const existingAppointments = await wixData.query('GFE_Appointments')
            .eq('scheduledDate', new Date(preferredDate))
            .find();
        
        // Simple availability check - max 5 appointments per day
        return existingAppointments.totalCount < 5;
        
    } catch (error) {
        console.error('Availability check error:', error);
        return false;
    }
}

async function sendAppointmentConfirmation(appointment) {
    try {
        await fetch(`${BACKEND_URL}/api/send-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'api-key'
            },
            body: JSON.stringify({
                to: appointment.customerEmail,
                subject: 'Appointment Confirmation - Good Faith Exteriors',
                template: 'appointment_confirmation',
                data: appointment
            })
        });
    } catch (error) {
        console.error('Appointment confirmation error:', error);
    }
}