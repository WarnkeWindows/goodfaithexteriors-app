// Good Faith Exteriors - Authentication System
// Handles customer authentication for headless app

import wixData from 'wix-data';
import { fetch } from 'wix-fetch';
import wixSecretsBackend from 'wix-secrets-backend';

const BACKEND_URL = "https://gfe-backend-837326026335.us-central1.run.app";

// Customer login
export async function post_customerLogin(request) {
    try {
        const { email, password } = await request.body.json();
        
        if (!email || !password) {
            return {
                status: 400,
                body: { error: 'Email and password are required' }
            };
        }
        
        // Authenticate customer
        const authResult = await authenticateCustomer(email, password);
        
        if (!authResult.success) {
            return {
                status: 401,
                body: { error: 'Invalid credentials' }
            };
        }
        
        // Generate session token
        const sessionToken = await generateSessionToken(authResult.customer);
        
        // Update last login
        await updateLastLogin(authResult.customer._id);
        
        return {
            status: 200,
            body: {
                success: true,
                token: sessionToken,
                customer: {
                    id: authResult.customer._id,
                    email: authResult.customer.email,
                    fullName: authResult.customer.fullName
                }
            }
        };
        
    } catch (error) {
        console.error('Customer login error:', error);
        return {
            status: 500,
            body: { error: 'Login failed' }
        };
    }
}

// Customer registration
export async function post_customerRegister(request) {
    try {
        const customerData = await request.body.json();
        
        // Validate required fields
        if (!customerData.email || !customerData.password || !customerData.fullName) {
            return {
                status: 400,
                body: { error: 'Email, password, and full name are required' }
            };
        }
        
        // Check if customer already exists
        const existingCustomer = await wixData.query('GFE_Customers')
            .eq('email', customerData.email)
            .find();
        
        if (existingCustomer.totalCount > 0) {
            return {
                status: 409,
                body: { error: 'Customer already exists' }
            };
        }
        
        // Hash password
        const hashedPassword = await hashPassword(customerData.password);
        
        // Create customer
        const customer = await wixData.save('GFE_Customers', {
            email: customerData.email,
            fullName: customerData.fullName,
            phone: customerData.phone || '',
            address: customerData.address || '',
            passwordHash: hashedPassword,
            userType: 'customer',
            registrationDate: new Date(),
            lastLogin: new Date(),
            isActive: true
        });
        
        // Send welcome email
        await sendWelcomeEmail(customer);
        
        // Generate session token
        const sessionToken = await generateSessionToken(customer);
        
        return {
            status: 201,
            body: {
                success: true,
                message: 'Customer registered successfully',
                token: sessionToken,
                customer: {
                    id: customer._id,
                    email: customer.email,
                    fullName: customer.fullName
                }
            }
        };
        
    } catch (error) {
        console.error('Customer registration error:', error);
        return {
            status: 500,
            body: { error: 'Registration failed' }
        };
    }
}

// Verify session token
export async function post_verifyToken(request) {
    try {
        const { token } = await request.body.json();
        
        if (!token) {
            return {
                status: 400,
                body: { error: 'Token is required' }
            };
        }
        
        const verification = await verifySessionToken(token);
        
        if (!verification.valid) {
            return {
                status: 401,
                body: { error: 'Invalid or expired token' }
            };
        }
        
        return {
            status: 200,
            body: {
                success: true,
                customer: verification.customer
            }
        };
        
    } catch (error) {
        console.error('Token verification error:', error);
        return {
            status: 500,
            body: { error: 'Token verification failed' }
        };
    }
}

// Password reset request
export async function post_passwordReset(request) {
    try {
        const { email } = await request.body.json();
        
        if (!email) {
            return {
                status: 400,
                body: { error: 'Email is required' }
            };
        }
        
        // Check if customer exists
        const customer = await wixData.query('GFE_Customers')
            .eq('email', email)
            .find();
        
        if (customer.totalCount === 0) {
            // Don't reveal if email exists or not
            return {
                status: 200,
                body: { message: 'If the email exists, a reset link has been sent' }
            };
        }
        
        // Generate reset token
        const resetToken = await generateResetToken(customer.items[0]);
        
        // Send reset email
        await sendPasswordResetEmail(customer.items[0], resetToken);
        
        return {
            status: 200,
            body: { message: 'Password reset link sent to your email' }
        };
        
    } catch (error) {
        console.error('Password reset error:', error);
        return {
            status: 500,
            body: { error: 'Password reset failed' }
        };
    }
}

async function authenticateCustomer(email, password) {
    try {
        const customer = await wixData.query('GFE_Customers')
            .eq('email', email)
            .eq('isActive', true)
            .find();
        
        if (customer.totalCount === 0) {
            return { success: false };
        }
        
        const customerData = customer.items[0];
        const isValidPassword = await verifyPassword(password, customerData.passwordHash);
        
        if (!isValidPassword) {
            return { success: false };
        }
        
        return {
            success: true,
            customer: customerData
        };
        
    } catch (error) {
        console.error('Authentication error:', error);
        return { success: false };
    }
}

async function hashPassword(password) {
    // In production, use proper password hashing
    // This is a simplified example
    const crypto = require('crypto');
    return crypto.createHash('sha256').update(password).digest('hex');
}

async function verifyPassword(password, hash) {
    const hashedPassword = await hashPassword(password);
    return hashedPassword === hash;
}

async function generateSessionToken(customer) {
    // Generate JWT token or similar
    // This is a simplified example
    const tokenData = {
        customerId: customer._id,
        email: customer.email,
        issued: Date.now(),
        expires: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
    };
    
    return Buffer.from(JSON.stringify(tokenData)).toString('base64');
}

async function verifySessionToken(token) {
    try {
        const tokenData = JSON.parse(Buffer.from(token, 'base64').toString());
        
        if (tokenData.expires < Date.now()) {
            return { valid: false };
        }
        
        const customer = await wixData.get('GFE_Customers', tokenData.customerId);
        
        return {
            valid: true,
            customer: {
                id: customer._id,
                email: customer.email,
                fullName: customer.fullName
            }
        };
        
    } catch (error) {
        return { valid: false };
    }
}

async function generateResetToken(customer) {
    const resetToken = Math.random().toString(36).substr(2, 32);
    
    // Save reset token to database
    await wixData.update('GFE_Customers', {
        _id: customer._id,
        resetToken: resetToken,
        resetTokenExpires: new Date(Date.now() + 60 * 60 * 1000) // 1 hour
    });
    
    return resetToken;
}

async function updateLastLogin(customerId) {
    try {
        await wixData.update('GFE_Customers', {
            _id: customerId,
            lastLogin: new Date()
        });
    } catch (error) {
        console.error('Update last login error:', error);
    }
}

async function sendWelcomeEmail(customer) {
    try {
        await fetch(`${BACKEND_URL}/api/send-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'api-key'
            },
            body: JSON.stringify({
                to: customer.email,
                subject: 'Welcome to Good Faith Exteriors',
                template: 'welcome_email',
                data: customer
            })
        });
    } catch (error) {
        console.error('Welcome email error:', error);
    }
}

async function sendPasswordResetEmail(customer, resetToken) {
    try {
        await fetch(`${BACKEND_URL}/api/send-email`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-API-Key': 'api-key'
            },
            body: JSON.stringify({
                to: customer.email,
                subject: 'Password Reset - Good Faith Exteriors',
                template: 'password_reset_email',
                data: {
                    ...customer,
                    resetToken: resetToken,
                    resetUrl: `https://goodfaithexteriors.com/reset-password?token=${resetToken}`
                }
            })
        });
    } catch (error) {
        console.error('Password reset email error:', error);
    }
}