# Good Faith Exteriors Wix Deployment Package

## 🚀 Overview
This package contains all the necessary files and configurations to deploy the Good Faith Exteriors website on Wix.

**Generated:** 2025-06-30 04:45:10

## 📦 Package Contents

### HTML Components (`html-components/`)
- `gfe-home-page.html` - Main homepage component
- `gfe-window-products.html` - Window products catalog
- `gfe-ai-window-estimator.html` - AI-powered window estimator
- `gfe-good-faith-estimator.html` - Quote calculator
- `gfe-ai-window-measure.html` - AI measurement tool

### Velo Code (`velo-backend/` and `velo-frontend/`)
- Backend HTTP functions for API integration
- Frontend page controllers for user interactions
- Data collection configurations
- Integration with Google Cloud backend

### Configurations (`configurations/`)
- `wix_site_config.json` - Complete site configuration
- `environment.env` - Environment variables

### Deployment Scripts (`deployment-scripts/`)
- `manual_deploy.sh` - Step-by-step manual deployment guide
- `api_deploy.py` - Automated API deployment script

## 🔧 Site Configuration

**Meta Site ID:** 5ec64f41-3f5e-4ba1-b9fc-018d3a8681a4
**Account ID:** 10d52dd8-ec9b-4453-adbc-6293b99af499
**App ID:** 477baa33-872c-4b41-8f1f-7d5e28a684f2
**Backend URL:** https://gfe-backend-837326026335.us-central1.run.app

**Editor URL:** 
https://editor.wix.com/html/editor/web/renderer/edit/b8574bad-dbbc-46a3-8d76-941a7101e5ac?metaSiteId=5ec64f41-3f5e-4ba1-b9fc-018d3a8681a4

## 🚀 Deployment Instructions

### Option 1: Manual Deployment (Recommended)
1. Run the manual deployment script:
   ```bash
   cd deployment-scripts
   ./manual_deploy.sh
   ```

2. Follow the step-by-step instructions displayed

### Option 2: API Deployment
1. Configure API credentials
2. Run the API deployment script:
   ```bash
   cd deployment-scripts
   python3 api_deploy.py
   ```

## 📊 Data Collections

The following Wix Data collections need to be created:

1. **GFE_Leads** - Customer lead information
2. **GFE_WindowProducts** - Window product catalog
3. **GFE_Customers** - Customer database
4. **GFE_Projects** - Project management
5. **GFE_Quotes** - Quote generation and tracking
6. **GFE_Contractors** - Contractor network
7. **GFE_MarketPrices** - Market pricing data
8. **GFE_PriceHistory** - Historical pricing

## 🔗 API Endpoints

- **AI Analysis:** https://gfe-backend-837326026335.us-central1.run.app/api/ai-analysis
- **Customer Service:** https://gfe-backend-837326026335.us-central1.run.app/api/customer-service
- **PDF Generation:** https://gfe-backend-837326026335.us-central1.run.app/api/generate-pdf
- **Lead Management:** https://gfe-backend-837326026335.us-central1.run.app/api/leads
- **Window Products:** https://gfe-backend-837326026335.us-central1.run.app/api/window-products

## 🎯 Features

- ✅ AI-powered window analysis
- ✅ Automated quote generation
- ✅ Customer portal
- ✅ Contractor network
- ✅ Real-time pricing
- ✅ Lead management
- ✅ Project tracking

## 📞 Support

For technical support or questions:
- Backend API Health: https://gfe-backend-837326026335.us-central1.run.app/health
- System Status: All systems operational

## 🎉 Next Steps

1. Complete Wix site deployment
2. Test all integrations
3. Train team on new system
4. Launch and monitor performance

Your Good Faith Exteriors system is ready for production!
